<?php
// Import PHPMailer classes into the global namespace
// These must be at the top of your script, not inside a function
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

//Load Composer's autoloader
include("includs/PHPMailer/src/Exception.php");
include("includs/PHPMailer/src/PHPMailer.php");
include("includs/PHPMailer/src/SMTP.php");

$mail = new PHPMailer(true);                              // Passing `true` enables exceptions
try {
    //Server settings
    $mail->SMTPDebug = 2;                                 // Enable verbose debug output
    $mail->isSMTP();                                      // Set mailer to use SMTP
    $mail->Host = 'apps.mylighthost.com';  // Specify main and backup SMTP servers
    $mail->SMTPAuth = true;                               // Enable SMTP authentication
    $mail->Username = 'hr@mylighthost.com';                 // SMTP username
    $mail->Password = 'oiwRH1u3lQYz';                           // SMTP password
    $mail->SMTPSecure = 'ssl';                            // Enable TLS encryption, `ssl` also accepted
    $mail->Port = 465;                                    // TCP port to connect to

    //Recipients
    $mail->setFrom('hr@mylighthost.com', 'Human Resourse');
    $mail->addAddress('nuruzzaman.himel147@gmail.com', 'Himel');     // Add a recipient
    //$mail->addAddress('rakibur@mylighthost.com');               // Name is optional
   // $mail->addReplyTo('info@example.com', 'Information');
   // $mail->addCC('cc@example.com');
  //  $mail->addBCC('bcc@example.com');

    //Attachments
   // $mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
   // $mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name
    // body................................
    
    
    $body = "

<!DOCTYPE html>
<html lang='en'>
<head>
	<meta charset='UTF-8'>
	<title>PHP Mailer</title>


	<style type='text/css'>
		@import url('https://fonts.googleapis.com/css?family=Open+Sans');

	</style>
</head>
<body style='font-size: 16px;font-family: font-family: 'Open Sans', sans-serif;line-height: 17px;margin:0px;padding:0px;outline:0px;'>
	

	
	<div class='headersection template clear' style='width:770px; margin:0px auto;overflow:hidden;	background: #6eaff9;color: #fff;font-size: 19px;min-height: 86px;border: 1px solid #60a1cd;border-radius: 3px;'>

		<div class='logo' style='float:left;width: 414px;'>
			<img src='https://cdn.mylighthost.com/img/logo.png' style='	float: left;width: 143px;padding: 18px 18px;'>
		</div>
		<div class='support' style='float: right;padding: 10px 10px;'>
			<p style='border: 1px solid #fff;padding: 6px;font-weight:bold ;'>Support: <strong style='font-style: italic;
	font-size: 15px;'>01735457483</strong></p>
		</div>

	</div>
	<div class='containersection template clear' style='width:770px; margin:0px auto;overflow:hidden;border: 1px dotted #c3ebef;min-height: 400px;background: url(http://cdn.mylighthost.com/hr/bg1.png)'>
		<div class='maintent clear' style='overflow:hidden;width: 603px;margin: 0px auto;background: #fffafa;border-radius: 5px;min-height: 350px;'>

			<div class='message clear' style='overflow:hidden;width: 100%;background: #C1F0FF;margin: 17px 0px;margin-bottom: 43px;'>
				<p style='font-size: 19px;text-transform: uppercase;display: block;width: 102px;margin: 21px auto;font-weight:bold;'>Message</p>
			</div>

			<div class='body clear' style='overflow:hidden;line-height: 24px;text-align: justify;font-size: 16px;padding: 16px;'>
				<p>
					Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
					tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
					quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
					consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
					cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
					proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
				</p>
			</div>
			
		</div>
	</div>
	<div class='footersection template clear' style='width:770px; margin:0px auto;overflow:hidden;background: #6eaff9;border-radius: 3px;'>
		<div class='footer' style='width: 100%;padding: 18px 5px'>
			<p style='width: 55%;margin: 0px auto;font-size: 15px;'>Copyright ©".date('Y')."  MyLightHost. All rights reserved.</p>
		</div>
	</div>

	<script type='text/javascript' src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js'></script>
	<script type='text/javascript' src='https://cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.min.js'></script>
	<script src='temcustom.js'></script>
	<script type='text/javascript' src='https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js'></script>
</body>
</html>
    ";
    
    
    //Content
    $mail->isHTML(true);                                  // Set email format to HTML
    $mail->Subject = 'Here is the subject';
    $mail->Body    = $body;
    $mail->AltBody = strip_tags($body);

    $mail->send();
    echo 'Message has been sent';
} catch (Exception $e) {
    echo 'Message could not be sent. Mailer Error: ', $mail->ErrorInfo;
}
?>