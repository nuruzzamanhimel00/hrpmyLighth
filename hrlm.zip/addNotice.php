<?php include("inc/header.php"); ?>
<?php include("inc/aside.php"); ?>
		<div class="col-md-9" style="margin-bottom: 20px;">
			<div class="bodySection">
				
				<div class="row">
					
					<div class="col-md-12 emplyCol8">
						<div class="setAtten" >
							<div class="addTitle">
								<p>Add Notice</p>
							</div>
							
							<div class="addNotice">
								
								<form action="" method="post">
									
									<div class="form-group row">
										<label for="inputPassword" class="col-sm-2 col-form-label">Department</label>
										<div class="col-sm-9">
											<select class="custom-select mr-sm-9" id="inlineFormCustomSelect">
												<option selected>Choose...</option>
												<option value="1">Dept 1</option>
												<option value="2">Dept 2</option>
												<option value="3">Dept 3</option>
												<option value="3">Dept 4</option>
												<option value="3">Dept 5</option>
											</select>
										</div>

									</div>
									<div class="form-group row">
										<label for="inputEmail3" class="col-sm-2 col-form-label">Title</label>
									    <div class="col-sm-9">
									      <input type="text" class="form-control" id="inputEmail3" placeholder="Email">
									    </div>
									</div>
									<div class="form-group row">
										<label for="inputEmail3" class="col-sm-2 col-form-label">Description</label>
									    <div class="col-sm-9">
									      <textarea class="tinymce"></textarea>
									    </div>
									</div>
									<div class="gobtn" style="width: 38%; margin-left: 10px;">
										<button type="submit" class="btn btn-primary">Submit</button>
									</div>
									
								</form>
							</div>
							
							
						</div>
						<!-- 	.col-md-6 div end..................... -->
					</div>
					
				</div>
				</div> <!-- col-md-10 end.............. -->
				
			</form>
		</div>
	</div>
</div>

<?php 
	include("inc/footer.php");
?>