<?php 
	define("DB_HOST", "db1.noc24online.net");
	define("DB_USER", "hrmylighthost_rootpayroll");
	define("DB_PASS", "GZ3uxc{aY8H3");
	define("DB_NAME", "hrmylighthost_dbhrpayroll");
?>