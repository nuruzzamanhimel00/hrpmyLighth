<?php 
	
	class Database{

		public $dbhost = DB_HOST;
		public $dbuser = DB_USER;
		public $dbpass = DB_PASS;
		public $dbname = DB_NAME;

		public $conn;
		public $error;

		public function __construct()
		{
			$this->connectDB();
		}


		public function connectDB()
		{
			$this->conn = new mysqli($this->dbhost,$this->dbuser,$this->dbpass,$this->dbname);

			if(!$this->conn)
			{
				echo "DB Connection Fail".$this->conn->connect_error;
				return FALSE;
			}
		}

		public function select($query)
		{
			$result = $this->conn->query($query) or die($this->conn->error.__LINE__);
			if($result->num_rows > 0)
			{
				return $result;
			}
			else{
				return FALSE;
			}
		}

		public function insert($table_name,$ass_data)
		{
			$query = "INSERT INTO ".$table_name."(".implode(",",array_keys($ass_data)).") VALUES('".implode("','",array_values($ass_data))."')";
			// echo $query;
			// exit();
			$result = $this->conn->query($query) OR die($this->conn->error.__LINE___);
			if($result)
			{
				return $result;
			}
			else
			{
				return FALSE;
			}
		}

		public function update($table_name,$data,$where)
		{
			$cols = array();

			foreach ($data as $key => $value) 
			{
				$cols[] = "$key = '$value'";
			}
			$query = "UPDATE ".$table_name." SET ".implode(",",$cols)." WHERE ".$where." ";	
			// echo $query;
			// exit();

			$result = $this->conn->query($query) OR die($this->conn->error.__LINE__);
			if($result)
			{
				return $result;
			}
			else
			{
				return FALSE;
			}

		}

		public function delete($table_name, $where)
		{
			$query = "DELETE FROM ".$table_name." WHERE ".$where." ";
			// echo $query;
			// exit();

			$result = $this->conn->query($query) OR die($this->conn->error.__LINE__);
			if($result)
			{
				return $result;
			}
			else
			{
				return FALSE;
			}

		}

	}
?>