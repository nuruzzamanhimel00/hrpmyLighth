
 <!-- class add............... -->
<?php include("classes/EmployeeLogin.php"); ?>
<?php Session::getlogin();  ?>

<?php 
  $el = new EmployeeLogin();
  if($_SERVER["REQUEST_METHOD"] == "POST" AND isset($_POST["signup"]))
  {
    $email = $_POST["email"];
    $pass  = md5($_POST["password"]);
    // echo "Email =".$email;
    // echo "pass =".$pass;
    // exit();
    $loginChk = $el->employeelog($email,$pass);
  }

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/fontawesome-all.min.css">
  <link rel="stylesheet" href="css/animate.css">
  <link rel="stylesheet" href="style.css">
  <title>HR-Admin</title>
</head>
<body>
<div class="mainContent">
	<div class="headerSection">	
  		<div class="container header_con">
  			<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="#">
		<div class="logo"> 
			<img src="images/logo.png" alt="logo">
		</div>  
  </a>
 <!--  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button> -->

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
   <!--  <ul class="navbar-nav ml-auto">
      <li class="nav-item ">
        <a class="nav-link userimg" href="#"> 
        	<img src="images/profile/himel.jpg" alt="User Image">
				<span style="color: #000;font-size: 17px;">Nuruzzaman Himel</span>
				 
        </a>
      </li>
    
    </ul> -->
  </div>
</nav>
  		</div>
  </div>
  
  <div class="containerSection"> 
  	<div class="container"> 
  		<div class="row"> 
  			<div class="col-md-8"> 
  				<div class="welcome"> 
  					<h1>Welcome</h1>
  					<p> 
  							Welcome To HR-Payroll Software.Welcome To HR-Payroll Software.Welcome To HR-Payroll Software.
  							Welcome To HR-Payroll Software.Welcome To HR-Payroll Software.Welcome To HR-Payroll Software.
  							Welcome To HR-Payroll Software.Welcome To HR-Payroll Software.Welcome To HR-Payroll Software.
  							Welcome To HR-Payroll Software.Welcome To HR-Payroll Software.Welcome To HR-Payroll Software.
  							Welcome To HR-Payroll Software.Welcome To HR-Payroll Software.Welcome To HR-Payroll Software.
  							Welcome To HR-Payroll Software.Welcome To HR-Payroll Software.Welcome To HR-Payroll Software.
  							Welcome To HR-Payroll Software.Welcome To HR-Payroll Software.Welcome To HR-Payroll Software.
  							Welcome To HR-Payroll Software.Welcome To HR-Payroll Software.Welcome To HR-Payroll Software.
  							
  					</p>
  				</div>
  			</div>
  			<div class="col-md-4"> 
  				<div class="login_part"> 
  					<div class="row" style="border: 1px solid #fff;padding: 15px 5px;"> 
  						<div class="col-md-12"> 
              <?php 
                if(isset( $loginChk))
                {
                  echo  $loginChk;
                }
              ?>

  							<form action="" method="post">
                  <div class="form-group ">
                    <label for="exampleInputEmail1">Email address</label>
                    <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email" name="email">
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Password</label>
                    <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password" name="password">
                  </div>
                  <div class="form-check">
                    <input type="checkbox" class="form-check-input" id="exampleCheck1">
                    <label class="form-check-label" for="exampleCheck1">Check me out</label>
                  </div>
                 <div >
                      <button type="submit" class="btn btn-primary  mr-4" name="signup" >SignUp</button>
                    <a href="findYourAccount.php " class="" style="position: relative;">
                      <span class="pt-4 " style="text-decoration: underline;position: absolute;width: 120px;top: -8px;">Forget Account</span>
                    </a>
                 </div>
            </form>


  						</div>
  					</div>
  					
  					 <div class="row justify-content-end">
                   <div class="col-md-4 btn">
        
                     <a href="#">Job Apply</a> 
                   </div>
                  <div class="col-md-4 btn">
                   <a href="#">Circular</a> 
                    
                  </div>
  					</div>
  			</div>
  		</div>
  	</div>
  </div>
  </div>
  
  <div class="footerSection bg-light"> 
  	<footer class="container"> 
  		<div class="fcopy bg-light text-center"  > 
  			<div class="row"> 
  				<div class="col-md-12"> 
  					<div class="copy"> 
  						<p>Copyright © 2019 MyLightHost. All Rights Reserved.</p>
  					</div>
  				</div>
  				</div>
  		</div>
  	</footer>
  </div>
  </div>
  






  <script src="js/jquery-3.3.1.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/wow.min.js"></script>
  <script src="custom.js"></script>
  <script src="js/modernizr-custom.js"></script>
</body>
</html>