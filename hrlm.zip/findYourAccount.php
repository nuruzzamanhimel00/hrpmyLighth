
<?php include("classes/EmployeePassRecov.php"); ?>



<?php Session::getlogin();  ?>
<?php
    $epr = new EmployeePassRecov();
   // $sm = new Mailsend();
    if($_SERVER["REQUEST_METHOD"] == "POST" AND isset($_POST["search"]))
    {

       $accountChk = $epr->findYourAccount($_POST);
    }
?>


</style>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/fontawesome-all.min.css">
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="style.css">
    <title>HR-Admin</title>
  </head>
  <body>
    <div class="mainContent">
      <div class="headerSection">
        <div class="container header_con">
          <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <a class="navbar-brand" href="#">
              <div class="logo">
                <img src="images/logo.png" alt="logo">
              </div>
            </a>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
              
            </div>
          </nav>
        </div>
      </div>
      
      <div class="containerSection">
        
        <div class="container">
          <div class="findbg">
          <div class="row">
            
              <!-- <div class="col-md-10"> -->
                <div class="findAcc">
                  
                  <div class="card findAccCard ">

                    <div class="card-header font-weight-bold">Find Your Account</div>

                    <div class="card-body text-center">
                <?php 
                  if(isset($accountChk))
                  {
                    echo $accountChk['message'] ;
                  }
                ?>      
                      <div class="card-text ">
                        <p class="">Please enter your email address or phone number to search you account</p>
                        

                        <form action="" method="post">
                            <div class="form-group ">
                                <div class="">
                                  <input type="text" name="data" class="form-control" id="" placeholder="Phone Number And Email Address" style="width: 68%;border-radius: 0px;font-style: italic;">
                                </div>
                            </div>
                        


                      </div>
                      
                    </div>

                    <div class="card-footer text-right m-0 py-1">
                      <button class="btn btn-primary mr-1" name="search" style="padding: 2px 9px; font-weight:bold;">Search</button>
                      <button class="btn btn-light mr-1" style="border:1px solid #ddd; padding: 2px 9px;">
                         <a href="login.php" class="" >Cancel</a>
                      </button>
                    
                    </div>
                  </form>
                  </div>
                  
                </div>
             <!--  </div> -->
            </div>
            
          </div>
        </div>
      </div>
      
      <div class="footerSection bg-light">
        <footer class="container">
          <div class="fcopy bg-light text-center"  >
            <div class="row">
              <div class="col-md-12">
                <div class="copy">
                  <p>Copyright © 2019 MyLightHost. All Rights Reserved.</p>
                </div>
              </div>
            </div>
          </div>
        </footer>
      </div>
    </div>
    
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/wow.min.js"></script>
    <script src="custom.js"></script>
    <script src="js/modernizr-custom.js"></script>
  </body>
</html>