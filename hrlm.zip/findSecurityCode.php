<?php include("classes/EmployeePassRecov.php"); ?>
<?php Session::getlogin();  ?>
<?php
$epr = new EmployeePassRecov();
if(isset($_GET['data']) AND !empty($_GET['data']))
{
$data = base64_decode($_GET['data']);
//echo $data;
// GET PASS CHECK................
  if(is_numeric($data))
  {

  }
  else
    {
    $gatePass = $epr->gatePassChecking($data);
    if($gatePass == FALSE)
    {
    header("Location: login.php");
    exit();
    }
  }

}
else
{
  header("Location: login.php");
  exit();
}
?>
<?php

// $sm = new Mailsend();
if($_SERVER["REQUEST_METHOD"] == "POST" AND isset($_POST["continue"]))
{
if(is_numeric($data))
{
}
else{
$codeChk = $epr->generateCodeCheck($_POST,$data);
}

}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/fontawesome-all.min.css">
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="style.css">
    <title>HR-Admin</title>
  </head>
  <body>
    <div class="mainContent">
      <div class="headerSection">
        <div class="container header_con">
          <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <a class="navbar-brand" href="#">
              <div class="logo">
                <img src="images/logo.png" alt="logo">
              </div>
            </a>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
              
            </div>
          </nav>
        </div>
      </div>
      
      <div class="containerSection">
        
        <div class="container">
          <div class="findbg">
            <div class="row">
              
              <!-- <div class="col-md-10"> -->
              <div class="findAcc">
                
                <div class="card findAccCard ">
                  <div class="card-header font-weight-bold">Choose a new password</div>
                  <div class="card-body text-center">
                  <?php 
                  if(isset($codeChk))
                  {
                    echo $codeChk['message'] ;
                  }
                ?> 
                    <div class="card-text ">
                      <p class="text-left">Please check your email for a message with our code. Your code is 6 digits long.</p>
                      
                      <form action="" method="post">
                        <div class="form-group row ">
                          <div class="col-sm-6">
                            <input type="text" name="getCode" class="ml-3 form-control" id="inputPassword" placeholder="Enter Code" style="width: 92%;height: 100%;font-size: 30px;">
                          </div>
                          <div class="col-sm-6 text-center">
                            <small class="font-weight-bold ml-5">We send your code to:</small>
                            <small class="ml-5">
                            <?php
                            if(is_numeric($data))
                            {
                            }else{
                            $gatePass = $epr->getHiddenEmail($data);
                            if(isset($gatePass))
                            {
                            echo $gatePass;
                            }
                            }
                            
                            ?>
                            </small>
                          </div>
                        </div>
                        
                      </div>
                      
                    </div>
                    
                    
                    <div class="card-footer text-right m-0 py-1">
                      <button class="btn btn-primary mr-1" name="continue" style="padding: 2px 9px; font-weight:bold;">Continue</button>
                      <button class="btn btn-light mr-1" style="border:1px solid #ddd; padding: 2px 9px;">
                      <a href="login.php" class="" >Cancel</a>
                      </button>
                      
                    </div>
                    
                  </div>
                </form>
              </div>
              <!--  </div> -->
            </div>
            
          </div>
        </div>
      </div>
      
      <div class="footerSection bg-light">
        <footer class="container">
          <div class="fcopy bg-light text-center"  >
            <div class="row">
              <div class="col-md-12">
                <div class="copy">
                  <p>Copyright © 2019 MyLightHost. All Rights Reserved.</p>
                </div>
              </div>
            </div>
          </div>
        </footer>
      </div>
    </div>
    
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/wow.min.js"></script>
    <script src="custom.js"></script>
    <script src="js/modernizr-custom.js"></script>
  </body>
</html>