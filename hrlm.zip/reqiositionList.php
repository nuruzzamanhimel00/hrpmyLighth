<?php include("inc/header.php"); ?>
<?php include("inc/aside.php"); ?>
					<div class="col-md-9" style="margin-bottom: 20px;"> 
						<div class="bodySection">
								<div class="row mb-3 text-white " style="background: #B0B0FC !important;width: 101%;height: 44px;margin-left: -5px;">
									<div class="col-md-12" style="font-weight: bold;margin: 8px 5px;font-size: 18px;">
										Employee List
									</div>
								</div>
							<div class="row"> 
								
								<div class="col-md-12 emplyCol8">
									<div class="emplyForm">
									<form> 
										<table id="example" class="display " style="border: 1px solid #ddd;">
									        <thead>
									            <tr>
									                <th width="5%">No</th>
									                <th width="20%">Requi Type</th>
									                <th width="20%">Action</th>
									                
									            </tr>
									        </thead>
									        <tbody>
									            <tr>
									                <td>01</td>
									                <td>Requisition Name</td>
									                
									              	<td>
									              		<a href="#">
									              			<button type="button" class="btn btn-primary" style="padding: 5px 10px;">Edit</button>
									              		</a>
									              		<a href="#" >
									              			<button type="button" class="btn btn-danger" style="padding: 5px 10px;" data-toggle="modal" data-target="#exampleModal">Delete</button>

									              		</a>
									              		
									              		
									              	</td>
									            </tr>
												<tr>
									                <td>01</td>
									                <td>Requisition Name</td>
									                
									              	<td>
									              		<a href="#">
									              			<button type="button" class="btn btn-primary" style="padding: 5px 10px;">Edit</button>
									              		</a>
									              		<a href="#" >
									              			<button type="button" class="btn btn-danger" style="padding: 5px 10px;" data-toggle="modal" data-target="#exampleModal">Delete</button>

									              		</a>
									              		
									              		
									              	</td>
									            </tr>
									            <tr>
									                <td>01</td>
									                <td>Requisition Name</td>
									                
									              	<td>
									              		<a href="#">
									              			<button type="button" class="btn btn-primary" style="padding: 5px 10px;">Edit</button>
									              		</a>
									              		<a href="#" >
									              			<button type="button" class="btn btn-danger" style="padding: 5px 10px;" data-toggle="modal" data-target="#exampleModal">Delete</button>

									              		</a>
									              		
									              		
									              	</td>
									            </tr>
									            <tr>
									                <td>01</td>
									                <td>Requisition Name</td>
									                
									              	<td>
									              		<a href="#">
									              			<button type="button" class="btn btn-primary" style="padding: 5px 10px;">Edit</button>
									              		</a>
									              		<a href="#" >
									              			<button type="button" class="btn btn-danger" style="padding: 5px 10px;" data-toggle="modal" data-target="#exampleModal">Delete</button>

									              		</a>
									              		
									              		
									              	</td>
									            </tr>
									            <tr>
									                <td>01</td>
									                <td>Requisition Name</td>
									                
									              	<td>
									              		<a href="#">
									              			<button type="button" class="btn btn-primary" style="padding: 5px 10px;">Edit</button>
									              		</a>
									              		<a href="#" >
									              			<button type="button" class="btn btn-danger" style="padding: 5px 10px;" data-toggle="modal" data-target="#exampleModal">Delete</button>

									              		</a>
									              		
									              		
									              	</td>
									            </tr>
									            <tr>
									                <td>01</td>
									                <td>Requisition Name</td>
									                
									              	<td>
									              		<a href="#">
									              			<button type="button" class="btn btn-primary" style="padding: 5px 10px;">Edit</button>
									              		</a>
									              		<a href="#" >
									              			<button type="button" class="btn btn-danger" style="padding: 5px 10px;" data-toggle="modal" data-target="#exampleModal">Delete</button>

									              		</a>
									              		
									              		
									              	</td>
									            </tr>
												
									           
									             


									             
									          </tbody>
									            
									        
									    </table>
									</form>
									</div>
								<!-- 	.col-md-6 div end..................... -->
								</div>
								

						</div>
					</div> <!-- col-md-10 end.............. -->
					
					</form>
				</div>
			</div>
		</div>
		
		<?php 
	include("inc/footer.php");
?>