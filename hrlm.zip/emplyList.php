<?php include("inc/header.php"); ?>
<?php include("inc/aside.php"); ?>
					<div class="col-md-9" style="margin-bottom: 20px;"> 
						<div class="bodySection">
								<div class="row mb-3 text-white " style="background: #B0B0FC !important;width: 101%;height: 44px;margin-left: -5px;">
									<div class="col-md-12" style="font-weight: bold;margin: 8px 5px;font-size: 18px;">
										Employee List
									</div>
								</div>
							<div class="row"> 
								
								<div class="col-md-12 emplyCol8">
									<div class="emplyForm">
										
										<table id="example" class="table table-striped table-bordered "style="border: 1px solid #ddd;margin-left: -43px;">
									        <thead>
									            <tr>
									            	 <th width="5%" class="text-center">No</th>
									                <th width="20%" class="text-center">Name</th>
									                <th width="15%" class="text-center">Department</th>
									                <th width="15%" class="text-center">Designation</th>
									                <th width="10%" class="text-center">Email</th>
									               
									                <th>View</th>
									            </tr>
									        </thead>
									        <tbody>
							<?php 
								 $showEmpLst = $em->showAllEmployeeList();
								 if($showEmpLst != FALSE)
								 {	
								 	$i = 0;
								 	while ($values = $showEmpLst->fetch_assoc()) {
									$i++;
							?>		        	
									            <tr>
									            	<td class="text-center">
									            		<p class="pt-3"><?php echo $i; ?></p>
									            	</td>
									                <td class="text-center">
									                	<p class="pt-3"><?php echo $values['name'];  ?>
									                		
									                	</p>
									                </td>
									                <td class="text-center">
									            		<p class="pt-3"><?php echo $values['deptname']; ?></p>
									            	</td>
									                <td class="text-center">
									                	<p class="pt-3"><?php echo $values['desigName'];  ?></p>
									                </td>
									                <td class="text-center">
									                	<p class="pt-3"><?php echo $values['email'];  ?></p>
									                </td>
									               
									              	<td class="text-center">
									              		<a href="viewProfile.php?vid=<?php echo base64_encode($values['id']); ?>" >
									              			<button type="button" class="btn btn-outline-primary p-0 mb-1" style="width:48px;">View</button>
									              		</a>
									            <?php 
									            	if(Session::sess_get('emplyId') == $values['id'])
									            	{
									            ?>  		
									              		<a href="editProfile.php?eid=<?php echo base64_encode($values['id']); ?>">
									              			<button type="button" class="btn btn-outline-success p-0 mb-1" style="width:48px;">Edit</button>
									              		</a>
									             <?php } ?> 		
									              		
									              	</td>
									            </tr>
							<?php } } ?>		            
									           
									           
									            
									        </tbody>

									           
									    </table>





										
		
									</div>
								<!-- 	.col-md-6 div end..................... -->
								</div>
								

						</div>
					</div> <!-- col-md-10 end.............. -->
					
					</form>
				</div>
			</div>
		</div>
		
<?php 
	include("inc/footer.php");
?>