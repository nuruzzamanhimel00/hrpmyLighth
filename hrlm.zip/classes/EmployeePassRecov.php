<?php 
  include("lib/Session.php");
  Session::sess_start();
?>
<?php 
    include_once("config/Config.php");
    include_once("lib/Database.php");
    include("helper/Formate.php");
?>
<!-- SEND MAIL class............................................ -->
<?php include("classes/Mailsend.php"); ?>
<?php 

	class EmployeePassRecov 
	{
		
		private $db;
	 	private $fm;
	 	private $sm;

	 	public function __construct()
	 	{
	 		$this->db = new Database();
	 		$this->fm = new Formate();
	 		$this->sm = new Mailsend();
	 	}

	 	public function findYourAccount($data)
	 	{

	 		$data = $this->fm->validation($data["data"]);

	 		$data = mysqli_real_escape_string($this->db->conn,$data);

	 		// echo $data;
	 		// exit();

	 		if(is_numeric($data))
	 		{
	 			$query = "SELECT * FROM Employee WHERE contuct='$data'  ";
	 			// echo $query;
	 			// exit();
	 			$contReslt = $this->db->select($query);
	 			// if number  found...........................
				if($contReslt != FALSE)
				{	$contValue = $contReslt->fetch_assoc();
					$id = $contValue['id'];
					$encodeId = base64_encode($id);
					//make a random code............
					$recovCode = substr(md5(time()),0,5);
					//echo $recovCode;
					$ass_data = array("recovCode"=>$recovCode);
					$udtRes = $this->db->update("Employee",$ass_data," id = '$id' ");


					if($udtRes != FALSE)
					{
						// header("Location: findSecurityCode.php?emplyeeId=$encodeId ");
						// exit();
						header("Location: findSecurityCode.php");
						exit();
					}

				}
				// if number not found...........................
				else{
					$response = array(
					"type" => "error",
					"message" => "
						<div class='alert alert-danger text-left' role='alert' style='background: #fae5e5;border: 1px solid #d52424;border-radius: 0px;padding: 4px 9px;'>
							<small style='font-weight: bold;color: black;font-size: 15px;'>No search results </small>
							<p class='font-weight-bold text-secondary mb-0' style='font-size: 14px;color: black !important;font-weight: normal !important;'>
								Your search did not return any results. Please try again with other information.
							</p>
									
						</div>
									
					"
					);
						return $response;

				}




	 		}
	 		// MAIN CONDITION FOR IF USER SET EMAIL FOR PASSWORD RECOVARY..........
	 		else{

	 			// DOMAIN CHECK....................................................
	 			$position = strpos($data,'@');
	 			$domain = substr($data,$position+1);
	 			// echo $domain;
	 			// exit();
	 			// DOMAIN CHECK END....................................................

	 			// DMAIN MATCH.....................................
	 			if($domain == "gmail.com")
	 			{
	 				$query = "SELECT * FROM Employee WHERE email='$data'  ";
		 			// echo $query;
		 			// exit();
		 			$AllReslt = $this->db->select($query);
		 			// IF EMAIL FOUND....................................
		 			if($AllReslt != FALSE)

					{	$value = $AllReslt->fetch_assoc();
						$id = $value['id'];
						
						$recovCode = substr(md5(time()),0,6);
						// echo $recovCode;
						// exit();
						$ass_data = array("recovCode"=>$recovCode);
						$udtRes = $this->db->update("Employee",$ass_data," id = '$id' ");

						// SEND MAIL..................
						 $sendMail = $this->sm->sendMail($value['email'],$value['name'],'Possword Recovary',"<p style='line-height:25px;'>Hi ".$value['name'].",<br>
We received a request to reset your Facebook password.Enter the following password reset code:  <b style='border:1px solid #ddd; padding:5px 6px;'>".$recovCode."</b> <p>");

						 //exit();

						if($udtRes != FALSE)
						{	
							header("Location: findSecurityCode.php?data=".base64_encode($data)." ");
							exit();
						// 	header("Location: findSecurityCode.php");
						// exit();
						}

					}
					// if EMAIL not found...........................
					else{
						$response = array(
						"type" => "error",
						"message" => "
							<div class='alert alert-danger text-left' role='alert' style='background: #fae5e5;border: 1px solid #d52424;border-radius: 0px;padding: 4px 9px;'>
								<small style='font-weight: bold;color: black;font-size: 15px;'>No search results </small>
								<p class='font-weight-bold text-secondary mb-0' style='font-size: 14px;color: black !important;font-weight: normal !important;'>
									Your search did not return any results. Please try again with other information.
								</p>
										
							</div>
										
						"
						);
							return $response;

					}


	 			}
	 			// DMAIN NOT MATCH.....................................
	 			else
	 			{
	 				$response = array(
						"type" => "error",
						"message" => "
							<div class='alert alert-danger text-left' role='alert' style='background: #fae5e5;border: 1px solid #d52424;border-radius: 0px;padding: 4px 9px;'>
								<small style='font-weight: bold;color: black;font-size: 15px;'> Searching results: </small>
								<p class='font-weight-bold text-secondary mb-0' style='font-size: 14px;color: black !important;font-weight: normal !important;'>
									Your search did not return any results. Please Insert Validate Email Address.
								</p>
										
							</div>
										
						"
						);
							return $response;
	 			}
	 			
	 			





	 		}
	 	}

	 	public function gatePassChecking($email)
	 	{
	 		$query = "SELECT * FROM Employee WHERE email='$email' ORDER BY id LIMIT 1  ";
		 			// echo $query;
		 			// exit();
		 	$reslt = $this->db->select($query);
		 	if($reslt != FALSE)
		 	{
		 		return $reslt;
		 	}
		 	else{
		 		return FALSE;
		 	}


	 	}

	 	public function getHiddenEmail($email)
	 	{
	 		// himel147@gmail.com

	 		$domainPos = strpos($email,'@');
	 		$domain = substr($email,$domainPos+1);

	 		$emlf = substr($email,0,2);
	 		$emlL = substr($email,$domainPos-2,2);

	 		$emlArray = array();

	 		if(filter_var($email,FILTER_VALIDATE_EMAIL))
	 		{
	 			$emlArray[] = $emlf;

	 			for ($i=1; $i <4 ; $i++) { 
	 				$emlArray[] = "*";
	 			}
	 			$emlArray[] = $emlL;
	 			$emlArray[] = $domain;
	 			//print_r($emlArray);
	 		}

	 		$hiddenEml = implode("",$emlArray);

	 		return $hiddenEml;
	 	}

	 	public function generateCodeCheck($data,$email)
	 	{
	 		$getCode = $this->fm->validation($data["getCode"]);
	 		$email = $this->fm->validation($email);

	 		$getCode = mysqli_real_escape_string($this->db->conn,$getCode);
	 		$email = mysqli_real_escape_string($this->db->conn,$email);

	 		// echo $getCode."<br>";
	 		// echo $email."<br>";

	 		$query = "SELECT * FROM Employee WHERE email='$email' ORDER BY id LIMIT 1  ";
		 			// echo $query;
		 			// exit();
		 	$reslt = $this->db->select($query);
		 	if($reslt != FALSE)
		 	{
		 		$emlValue = $reslt->fetch_assoc();
		 	}
		 	else{
		 		return FALSE;
		 	}

		 	// IF GENERATED CODE MATCH....................
		 	if($emlValue['recovCode'] == $getCode)
		 	{
		 		$id = $emlValue['id'];
		 		$ass_data = array("recovCode"=>" ");
				$udtRes = $this->db->update("Employee",$ass_data," id = '$id' ");

		 		header("Location: findNewPass.php?data=".base64_encode($email)." ");
							exit();
		 	}
		 	// IF CODE NOT MATCH.........................
		 	else{
		 		$response = array(
				"type" => "error",
				"message" => "
					<div class='alert alert-danger text-left' role='alert' style='background: #fae5e5;border: 1px solid #d52424;border-radius: 0px;padding: 4px 9px;'>
						<small style='font-weight: bold;color: black;font-size: 15px;'> Searching results: </small>
						<p class='font-weight-bold text-secondary mb-0' style='font-size: 14px;color: black !important;font-weight: normal !important;'>
							The number that you've entered doesn't match your code. Please try again.
						</p>
								
					</div>
								
				"
				);
					return $response;
 			}






	 	}

	 	public function confirmPass($data,$email)
	 	{
	 		$newpass = $data["newpass"];
	 		$confrmpass =$data["confrmpass"];
	 		$email = $this->fm->validation($email);

	 		$newpass = mysqli_real_escape_string($this->db->conn,$newpass);
	 		$confrmpass = mysqli_real_escape_string($this->db->conn,$confrmpass);
	 		$email = mysqli_real_escape_string($this->db->conn,$email);

	 		// echo $getCode."<br>";
	 		// echo $email."<br>";

	 		$query = "SELECT * FROM Employee WHERE email='$email' ORDER BY id LIMIT 1  ";
		 			// echo $query;
		 			// exit();
		 	$reslt = $this->db->select($query);
		 	if($reslt != FALSE)
		 	{
		 		$emlValue = $reslt->fetch_assoc();
		 	}
		 	else{
		 		return FALSE;
		 	}

		 	if(empty($newpass) OR empty($confrmpass))
		 	{
		 		$response = array(
				"type" => "error",
				"message" => "
					<div class='alert alert-danger text-left' role='alert' style='background: #fae5e5;border: 1px solid #d52424;border-radius: 0px;padding: 4px 9px;'>
						<small style='font-weight: bold;color: black;font-size: 15px;'> Submit results: </small>
						<p class='font-weight-bold text-secondary mb-0' style='font-size: 14px;color: black !important;font-weight: normal !important;'>
							Field Can't Empty!!
						</p>
								
					</div>
								
				"
				);
					return $response;
		 	}
		 	// OLD PASSWORD CHECK.........................
		 	elseif(md5($newpass) == $emlValue['password'] OR md5($confrmpass) == $emlValue['password'])
		 	{

		 		$response = array(
				"type" => "error",
				"message" => "
					<div class='alert alert-danger text-left' role='alert' style='background: #fae5e5;border: 1px solid #d52424;border-radius: 0px;padding: 4px 9px;'>
						<small style='font-weight: bold;color: black;font-size: 15px;'> Submit results: </small>
						<p class='font-weight-bold text-secondary mb-0' style='font-size: 14px;color: black !important;font-weight: normal !important;'>
							Warning
							Password Invalid. Please give New password.
						</p>
								
					</div>
								
				"
				);
					return $response;
		 	}
		 	// IF GENERATED CODE MATCH....................
		 	elseif($newpass == $confrmpass AND strlen($newpass) >= 5 AND strlen($confrmpass) >= 5)
		 	{
		 		$newpass = md5($newpass);
		 		$id = $emlValue['id'];
		 		$ass_data = array("password"=>$newpass);
				$udtRes = $this->db->update("Employee",$ass_data," id = '$id' ");

				// CHANGE PASSWORD MAIL..................
			 $sendMail = $this->sm->sendMail($emlValue['email'],$emlValue['name'],'Possword Change',"<p style='line-height:25px;'>Hi ".$emlValue['name'].",<br>
Your Password hase been updated. If you are not the person who requested, please contuct Our Technical Department. Thanks You. <p>");

		 		header("Location: login.php");
				exit();
		 	}
		 	elseif(strlen($newpass) < 6 OR strlen($confrmpass) < 6)
		 	{
		 		$response = array(
				"type" => "error",
				"message" => "
					<div class='alert alert-danger text-left' role='alert' style='background: #fae5e5;border: 1px solid #d52424;border-radius: 0px;padding: 4px 9px;'>
						<small style='font-weight: bold;color: black;font-size: 15px;'> Submit results: </small>
						<p class='font-weight-bold text-secondary mb-0' style='font-size: 14px;color: black !important;font-weight: normal !important;'>
							Warning
							Password must be at least 6 characters in length.
						</p>
								
					</div>
								
				"
				);
					return $response;
		 	}
		 	// IF CODE NOT MATCH.........................
		 	else{
		 		$response = array(
				"type" => "error",
				"message" => "
					<div class='alert alert-danger text-left' role='alert' style='background: #fae5e5;border: 1px solid #d52424;border-radius: 0px;padding: 4px 9px;'>
						<small style='font-weight: bold;color: black;font-size: 15px;'> Submit results: </small>
						<p class='font-weight-bold text-secondary mb-0' style='font-size: 14px;color: black !important;font-weight: normal !important;'>
							The Password that you've entered doesn't match. Please enter same password.
						</p>
								
					</div>
								
				"
				);
					return $response;
 			}






	 	}





	 	
	}
?>