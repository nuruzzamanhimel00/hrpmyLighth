<?php 
  include("lib/Session.php");
  Session::sess_start();
?>
<?php 
    include_once("config/Config.php");
    include_once("lib/Database.php");
    include("helper/Formate.php");
?>
<?php 
 
 class EmployeeLogin
 {
 	private $db;
 	private $fm;
 	public function __construct()
 	{
 		$this->db = new Database();
 		$this->fm = new Formate();
 	}


 	public function employeelog($email,$pass)
 	{
 		$email = $this->fm->validation($email);
 		$pass = $pass;

 		$email = mysqli_real_escape_string($this->db->conn,$email);
 		$pass = mysqli_real_escape_string($this->db->conn,$pass);

 		if(empty($email) OR empty($pass))
 		{
 			$msg = "
				<div class='alert alert-warning alert-dismissible fade show p-0 mb-2' role='alert'>
				 <p class='font-weight-bold text-danger py-2 px-2 ml-1 mb-0'>Field Can't Empty!!</p>
				 <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
				    <span aria-hidden='true'>&times;</span>
				  </button>
				</div>
 			";
 			return $msg;
 		}
 		else{
 			$query = "SELECT * FROM Employee WHERE email = '$email' AND password ='$pass' ORDER BY id LIMIT 1  ";
 			$result = $this->db->select($query);
 			if($result != FALSE)
 			{
 				$value = $result->fetch_assoc();

 				Session::sess_set("login",TURE);
 				Session::sess_set("emplyId",$value['id']);
 				Session::sess_set("emplyName",$value['name']);
 				Session::sess_set("emplyEmail",$value['email']);
 				Session::sess_set("emplyDesignation",$value['designationId']);
 				$this->fm->redirect_to("index.php");

 			}
 			else{
 				$msg = "
					<div class='alert alert-warning alert-dismissible fade show p-0 mb-2' role='alert'>
				 <p class='font-weight-bold text-danger py-2 px-2 ml-1 mb-0'>Email and Password not Match !!</p>
				 <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
				    <span aria-hidden='true'>&times;</span>
				  </button>
				</div>
 				";
 				return $msg;
 			}
 		}
 	}


 }
?>