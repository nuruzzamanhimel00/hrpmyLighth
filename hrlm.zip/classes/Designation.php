<?php 

	/**
	 * 
	 */
	class Designation
	{
		
		private $db;
	 	private $fm;
	 	public function __construct()
	 	{
	 		$this->db = new Database();
	 		$this->fm = new Formate();
	 	}

	 	public function addDesignation($data)
 	{
 		$desigName = $this->fm->validation($data["desigName"]);
 		$desigName = mysqli_real_escape_string($this->db->conn,$desigName);

 		$ass_data = array("desigName"=>$desigName);

 		$degRes = $this->db->insert("Designation",$ass_data);

 		if($degRes != FALSE)
		 	 	{
		 	 		
		 	 		 $response = array(
		            "type" => "success",
		            "message" => "
						<div class='alert alert-success alert-dismissible fade show p-0 mb-2' role='alert'>
						 <p class='font-weight-bold text-secondary py-2 px-2 ml-1 mb-0'>
							Successfully Added Designation.
						 </p>
					
						</div>
						
		            "
		        );
		         return $response;
		 	 	}
		 	 	else
		 	 	{
		 	 		 $response = array(
		            "type" => "success",
		            "message" => "
						<div class='alert alert-danger alert-dismissible fade show p-0 mb-2' role='alert'>
						 <p class='font-weight-bold text-secondary py-2 px-2 ml-1 mb-0'>
							Fail to add Designation !!
						 </p>
					
						</div>
						
		            "
		        );
		         return $response;
		 	 	}

 	}

 	public function showAllDesignation()
 	{
 		$query = "SELECT * FROM Designation ORDER BY id ASC ";
 		$desgReslt = $this->db->select($query);
 		if($desgReslt != FALSE)
 		{
 			return $desgReslt;
 		}
 		else{
 			return FALSE;
 		}
 	}

 	public function getDesignationById($id)
 	{
 		$query = "SELECT * FROM Designation WHERE id = '$id' ";
 		$degReslt = $this->db->select($query);
 		if($degReslt != FALSE)
 		{
 			return $degReslt;
 		}
 		else{
 			return FALSE;
 		}
 	}

 	public function udtDesignationById($data)
 	{
 		$id = $this->fm->validation($data["id"]);
 		$desigName = $this->fm->validation($data["desigName"]);

 		$id = mysqli_real_escape_string($this->db->conn,$id);
 		$desigName = mysqli_real_escape_string($this->db->conn,$desigName);

 		// echo "ID =".$id."<br>";
 		// echo "emplyType =".$emplyType."<br>";
 		// exit();

 		$ass_data = array("desigName"=>$desigName);
 		$udtRes = $this->db->update("Designation",$ass_data," id = '$id' ");

 		if($udtRes != FALSE)
	 	 	{
	 	 		
	 	 		 $response = array(
	            "type" => "success",
	            "message" => "
					<div class='alert alert-success alert-dismissible fade show p-0 mb-2' role='alert'>
					 <p class='font-weight-bold text-secondary py-2 px-2 ml-1 mb-0'>
						Successfully Update Designation.
					 </p>
				
					</div>
					
	            "
	        );
	         return $response;
	 	 	}
	 	 	else
	 	 	{
	 	 		 $response = array(
	            "type" => "success",
	            "message" => "
					<div class='alert alert-danger alert-dismissible fade show p-0 mb-2' role='alert'>
					 <p class='font-weight-bold text-secondary py-2 px-2 ml-1 mb-0'>
						Fail to Update Designation !!
					 </p>
				
					</div>
					
	            "
	        );
	         return $response;
	 	 	}

 	}

 	public function dltDesignationById($id)
 	{
 		$id = $this->fm->validation($id);
 		
 		$id = mysqli_real_escape_string($this->db->conn,$id);


 		$dltRes = $this->db->delete("Designation"," id = '$id'");
 		if($dltRes != FALSE)
	 	 	{
	 	 		
	 	 		 return $dltRes;
	 	 	}
	 	 	else
	 	 	{
	 	 		return FALSE;
	 	 	}
 		
 	}




	}
?>