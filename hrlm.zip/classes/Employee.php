<?php
class Employee
{
	private $db;
	private $fm;
	public function __construct()
	{
		$this->db = new Database();
		$this->fm = new Formate();
	}
	public function emplyInfoByid($emplyId,$emplyEmail)
	{
		$emplyId = $this->fm->validation($emplyId);
		$emplyEmail = $this->fm->validation($emplyEmail);
		
		$emplyId = mysqli_real_escape_string($this->db->conn,$emplyId);
		$emplyEmail = mysqli_real_escape_string($this->db->conn,$emplyEmail);
		$query = "SELECT * FROM Employee WHERE id = '$emplyId' AND email ='$emplyEmail' ORDER BY id LIMIT 1  ";
		$result = $this->db->select($query);
		if($result != FALSE)
		{
			return $result;
		}
		else{
			return FALSE;
		}
	}
	
	public function showAllDept()
	{
		$query = "SELECT * FROM Department ORDER BY id ASC ";
		$dptReslt = $this->db->select($query);
		if($dptReslt != FALSE)
		{
			return $dptReslt;
		}
		else{
			return FALSE;
		}
	}
	public function showAllEmpType()
	{
		$query = "SELECT * FROM EmployType ORDER BY id ASC ";
		$EtReslt = $this->db->select($query);
		if($EtReslt != FALSE)
		{
			return $EtReslt;
		}
		else{
			return FALSE;
		}
	}
	public function getEmplyTypebyId($id)
	{
		$query = "SELECT * FROM EmployType WHERE id = '$id' ";
		$EtReslt = $this->db->select($query);
		if($EtReslt != FALSE)
		{
			return $EtReslt;
		}
		else{
			return FALSE;
		}
	}
	public function showAllDegic()
	{
		$query = "SELECT * FROM Designation ORDER BY id ASC ";
		$desReslt = $this->db->select($query);
		if($desReslt != FALSE)
		{
			return $desReslt;
		}
		else{
			return FALSE;
		}
	}
	public function showAllEdu()
	{
		$query = "SELECT * FROM Education ORDER BY id ASC ";
		$eduReslt = $this->db->select($query);
		if($eduReslt != FALSE)
		{
			return $eduReslt;
		}
		else{
			return FALSE;
		}
	}
	public function addEmployee($data)
	{
		$password = md5($data['password']);
		
		
		$cardNo = $this->fm->validation($data["cardNo"]);
		$name = $this->fm->validation($data["name"]);
		$departmentId = $this->fm->validation($data["departmentId"]);
		$dateOfBirth = $this->fm->validation($data["dateOfBirth"]);
		$fathername = $this->fm->validation($data["fathername"]);
		$mothername = $this->fm->validation($data["mothername"]);
		$maritalStatus = $this->fm->validation($data["maritalStatus"]);
		$bloodGroup = $this->fm->validation($data["bloodGroup"]);
		$NID = $this->fm->validation($data["NID"]);
		$educationId = $this->fm->validation($data["educationId"]);
		$gender = $this->fm->validation($data["gender"]);
		$employTypeId = $this->fm->validation($data["employTypeId"]);
		$designationId = $this->fm->validation($data["designationId"]);
		$presentAddress = $this->fm->validation($data["presentAddress"]);
		$permanentAddress = $this->fm->validation($data["permanentAddress"]);
		$contuct = $this->fm->validation($data["contuct"]);
		$religion = $this->fm->validation($data["religion"]);
		$email = $this->fm->validation($data["email"]);
		$password = $this->fm->validation($password);
		
		$cardNo = mysqli_real_escape_string($this->db->conn,$cardNo);
		$name = mysqli_real_escape_string($this->db->conn,$name);
		$departmentId = mysqli_real_escape_string($this->db->conn,$departmentId);
		$dateOfBirth = mysqli_real_escape_string($this->db->conn,$dateOfBirth);
		$fathername = mysqli_real_escape_string($this->db->conn,$fathername);
		$mothername = mysqli_real_escape_string($this->db->conn,$mothername);
		$maritalStatus = mysqli_real_escape_string($this->db->conn,$maritalStatus);
		$bloodGroup = mysqli_real_escape_string($this->db->conn,$bloodGroup);
		$NID = mysqli_real_escape_string($this->db->conn,$NID);
		$educationId = mysqli_real_escape_string($this->db->conn,$educationId);
		$gender = mysqli_real_escape_string($this->db->conn,$gender);
		$employTypeId = mysqli_real_escape_string($this->db->conn,$employTypeId);
		$designationId = mysqli_real_escape_string($this->db->conn,$designationId);
		$presentAddress = mysqli_real_escape_string($this->db->conn,$presentAddress);
		$permanentAddress = mysqli_real_escape_string($this->db->conn,$permanentAddress);
		$contuct = mysqli_real_escape_string($this->db->conn,$contuct);
		$religion = mysqli_real_escape_string($this->db->conn,$religion);
		
		$email = mysqli_real_escape_string($this->db->conn,$email);
		$password = mysqli_real_escape_string($this->db->conn,$password);
		Session::sess_set("cardNo",$cardNo);
		Session::sess_set("name",$name);
		Session::sess_set("departmentId",$departmentId);
		Session::sess_set("dateOfBirth",$dateOfBirth);
		
		Session::sess_set("fathername",$fathername);
		Session::sess_set("mothername",$mothername);
		Session::sess_set("maritalStatus",$maritalStatus);
		Session::sess_set("bloodGroup",$bloodGroup);
		Session::sess_set("NID",$NID);
		Session::sess_set("educationId",$educationId);
		Session::sess_set("gender",$gender);
		Session::sess_set("employTypeId",$employTypeId);
		Session::sess_set("designationId",$designationId);
		Session::sess_set("presentAddress",$presentAddress);
		Session::sess_set("permanentAddress",$permanentAddress);
		Session::sess_set("contuct",$contuct);
		Session::sess_set("religion",$religion);
		Session::sess_set("email",$email);
		Session::sess_set("password",$password);
		// echo $cardNo."<br>";
		// echo $table_name;
		// exit();
		
		$permited = array("jpg","jpeg","png","gif");
		// for signature image upload............
		$simg_file_name = $_FILES['simage']['name'];
		$simg_file_size = $_FILES['simage']['size'];
		// Get Image Dimension
		$simg_info = @getimagesize($_FILES['simage']['tmp_name']);
		$swidth = $simg_info[0];
	$sheight = $simg_info[1];
		$sdiv = explode(".",$simg_file_name);
		$sextension = strtolower(end($sdiv));
		$suniq = substr(md5(time()),0,10).".".$sextension;
		$supload = "images/signature/$suniq";
		
		//for profile image upload............
		$pimg_file_name = $_FILES['pimage']['name'];
		$pimg_file_size = $_FILES['pimage']['size'];
		// Get Image Dimension
		$pimg_info = @getimagesize($_FILES['pimage']['tmp_name']);
		$pwidth = $pimg_info[0];
	$pheight = $pimg_info[1];
		$pdiv = explode(".",$pimg_file_name);
		$pextension = strtolower(end($pdiv));
		$puniq = substr(md5(time()),0,10).".".$pextension;
		$pupload = "images/profile/$puniq";
		$ass_data = array("cardNo" => $cardNo,'name'=> $name,'departmentId' => $departmentId,'dateOfBirth' => $dateOfBirth,'fathername' => $fathername ,'mothername' => $mothername, 'maritalStatus' => $maritalStatus,'bloodGroup' => $bloodGroup,'NID' => $NID,'presentAddress'=> $presentAddress,'permanentAddress'=> $permanentAddress, 'contuct'=> $contuct,'educationId' => $educationId,'email'=> $email,'password'=> $password,'gender'=>$gender,'religion'=>$religion,'designationId' => $designationId,'signature'=> $supload,'image' => $pupload,'employTypeId' => $employTypeId);
 // echo "<pre>";
	 // print_r($ass_data);
		// echo "</pre>";
		// echo $pupload;
		// exit();
		if(empty($cardNo) || empty($name) || empty($departmentId) || empty($dateOfBirth) || empty($fathername) || empty($mothername) || empty($maritalStatus) || empty($bloodGroup) || empty($NID) || empty($educationId) || empty($gender) || empty($employTypeId) || empty($designationId) || empty($presentAddress) || empty($permanentAddress) || empty($contuct) || empty($religion) || empty($email) || empty($password) || empty($simg_file_name) || empty($pimg_file_name) )
		{
			$response = array(
"type" => "error",
"message" => "
				<div class='alert alert-danger alert-dismissible fade show p-0 mb-2' role='alert'>
								<p class='font-weight-bold text-secondary py-2 px-2 ml-1 mb-0'>Field Can't Empty!!</p>
							
				</div>
"
		);
			return $response;
		}
		else if(!empty($simg_file_name)  AND !empty($pimg_file_name))
		{
			if($simg_file_size > 2000000)
			{
				$response = array(
		"type" => "error",
		"message" => "
						<div class='alert alert-danger alert-dismissible fade show p-0 mb-2' role='alert'>
										<p class='font-weight-bold text-secondary py-2 px-2 ml-1 mb-0'>Signature Image Size exceeds <span class='text-primary'> 2MB</span></p>
									
						</div>
		"
		);
		return $response;
			}
			else if(in_array($sextension,$permited) === FALSE)
			{
				$response = array(
		"type" => "error",
		"message" => "
						<div class='alert alert-danger alert-dismissible fade show p-0 mb-2' role='alert'>
										<p class='font-weight-bold text-secondary py-2 px-2 ml-1 mb-0'>
															You can upload only <span class='text-primary'>".implode(',',$permited)."</span>
										</p>
									
						</div>
		"
		);
		return $response;
			}
			else if ($swidth > "300" || $sheight > "200")
			{
		$response = array(
		"type" => "error",
		"message" => "
						<div class='alert alert-danger alert-dismissible fade show p-0 mb-2' role='alert'>
										<p class='font-weight-bold text-secondary py-2 px-2 ml-1 mb-0'>
															Signature Image dimension should be within <span class='text-primary'>(300X200)</span>
										</p>
									
						</div>
						
		"
		);
		return $response;
			}
			else if($pimg_file_size > 2000000)
			{
				$response = array(
		"type" => "error",
		"message" => "
						<div class='alert alert-danger alert-dismissible fade show p-0 mb-2' role='alert'>
										<p class='font-weight-bold text-secondary py-2 px-2 ml-1 mb-0'>Photo Size exceeds <span class='text-primary'>2MB</span></p>
									
						</div>
		"
		);
		return $response;
			}
		else if(in_array($pextension,$permited) === FALSE)
			{
				$response = array(
		"type" => "error",
		"message" => "
						<div class='alert alert-danger alert-dismissible fade show p-0 mb-2' role='alert'>
										<p class='font-weight-bold text-secondary py-2 px-2 ml-1 mb-0'>
															You can upload only <span class='text-primary'>".implode(',',$permited)."</span>
										</p>
									
						</div>
		"
		);
		return $response;
			}
			else if ($pwidth > "300" || $pheight > "300")
			{
		$response = array(
		"type" => "error",
		"message" => "
						<div class='alert alert-danger alert-dismissible fade show p-0 mb-2' role='alert'>
										<p class='font-weight-bold text-secondary py-2 px-2 ml-1 mb-0'>
															Photo dimension should be within <span class='text-primary'>(300X300)</span>
										</p>
									
						</div>
						
		"
		);
		return $response;
			}
			// else{
							// 	move_uploaded_file($_FILES['pimage']['tmp_name'],$pupload);
			// }
			else{
				$nquery = "SELECT * FROM Employee WHERE NID ='$NID' ";
				$ncheck = $this->db->select($nquery);
				if($ncheck != FALSE)
				{
					$response = array(
		"type" => "error",
		"message" => "
						<div class='alert alert-danger alert-dismissible fade show p-0 mb-2' role='alert'>
										<p class='font-weight-bold text-secondary py-2 px-2 ml-1 mb-0'>
															This NID number Already Exists!!.
										</p>
									
						</div>
						
		"
		);
			return $response;
				}
				$equery = "SELECT * FROM Employee WHERE email ='$email' ";
				$echeck = $this->db->select($equery);
				if($echeck != FALSE)
				{
					$response = array(
		"type" => "error",
		"message" => "
						<div class='alert alert-danger alert-dismissible fade show p-0 mb-2' role='alert'>
										<p class='font-weight-bold text-secondary py-2 px-2 ml-1 mb-0'>
															Email Already Exists!!.
										</p>
									
						</div>
						
		"
		);
			return $response;
				}
				
				$result = $this->db->insert("Employee",$ass_data);
				move_uploaded_file($_FILES['simage']['tmp_name'],$supload);
					move_uploaded_file($_FILES['pimage']['tmp_name'],$pupload);
		Session::sess_set("cardNo",NULL);
		Session::sess_set("name",NULL);
		Session::sess_set("departmentId",NULL);
		Session::sess_set("dateOfBirth",NULL);
		
		Session::sess_set("fathername",NULL);
		Session::sess_set("mothername",NULL);
		Session::sess_set("maritalStatus",NULL);
		Session::sess_set("bloodGroup",NULL);
		Session::sess_set("NID",NULL);
		Session::sess_set("educationId",NULL);
		Session::sess_set("gender",NULL);
		Session::sess_set("employTypeId",NULL);
		Session::sess_set("designationId",NULL);
		Session::sess_set("presentAddress",NULL);
		Session::sess_set("permanentAddress",NULL);
		Session::sess_set("contuct",NULL);
		Session::sess_set("religion",NULL);
		Session::sess_set("email",NULL);
		Session::sess_set("password",NULL);
				if($result != FALSE)
				{
					
					$response = array(
		"type" => "success",
		"message" => "
						<div class='alert alert-success alert-dismissible fade show p-0 mb-2' role='alert'>
										<p class='font-weight-bold text-secondary py-2 px-2 ml-1 mb-0'>
															Successfully Added Employee.
										</p>
									
						</div>
						
		"
		);
		return $response;
				}
				else{
					$response = array(
		"type" => "error",
		"message" => "
						<div class='alert alert-danger alert-dismissible fade show p-0 mb-2' role='alert'>
										<p class='font-weight-bold text-secondary py-2 px-2 ml-1 mb-0'>
															Successfully Added Employee.
										</p>
									
						</div>
						
		"
		);
		return $response;
				}
			}
		}
	}
	public function showAllEmployeeList()
	{
		$query = "SELECT Employee.*,Department.deptname,Designation.desigName
				FROM Employee
				INNER JOIN Department
					ON Employee.departmentId = Department.id
				INNER JOIN Designation
					ON Employee.designationId = Designation.id
				ORDER BY Employee.id ASC;
		";
		$eResult = $this->db->select($query);
		if($eResult != FALSE)
		{
			return $eResult;
		}
		else{
			return FALSE;
		}
	}
	public function addEmployeeType($data)
	{
		$emplyType = $this->fm->validation($data["emplyType"]);
		$emplyType = mysqli_real_escape_string($this->db->conn,$emplyType);
		$ass_data = array("emplyType"=>$emplyType);
		$empTypRes = $this->db->insert("EmployType",$ass_data);
		if($empTypRes != FALSE)
				{
					
					$response = array(
		"type" => "success",
		"message" => "
						<div class='alert alert-success alert-dismissible fade show p-0 mb-2' role='alert'>
										<p class='font-weight-bold text-secondary py-2 px-2 ml-1 mb-0'>
															Successfully Added Employee Type.
										</p>
									
						</div>
						
		"
		);
		return $response;
				}
				else
				{
					$response = array(
		"type" => "success",
		"message" => "
						<div class='alert alert-danger alert-dismissible fade show p-0 mb-2' role='alert'>
										<p class='font-weight-bold text-secondary py-2 px-2 ml-1 mb-0'>
															Fail to add Emplye Type !!
										</p>
									
						</div>
						
		"
		);
		return $response;
				}
	}
	public function udtEmployeeTypeById($data)
	{
		$id = $this->fm->validation($data["id"]);
		$emplyType = $this->fm->validation($data["emplyType"]);
		$id = mysqli_real_escape_string($this->db->conn,$id);
		$emplyType = mysqli_real_escape_string($this->db->conn,$emplyType);
		// echo "ID =".$id."<br>";
		// echo "emplyType =".$emplyType."<br>";
		// exit();
		$ass_data = array("emplyType"=>$emplyType);
		$udtRes = $this->db->update("EmployType",$ass_data," id = '$id' ");
		if($udtRes != FALSE)
			{
				
				$response = array(
	"type" => "success",
	"message" => "
					<div class='alert alert-success alert-dismissible fade show p-0 mb-2' role='alert'>
									<p class='font-weight-bold text-secondary py-2 px-2 ml-1 mb-0'>
														Successfully Update Employee Type.
									</p>
								
					</div>
					
	"
	);
	return $response;
			}
			else
			{
				$response = array(
	"type" => "success",
	"message" => "
					<div class='alert alert-danger alert-dismissible fade show p-0 mb-2' role='alert'>
									<p class='font-weight-bold text-secondary py-2 px-2 ml-1 mb-0'>
														Fail to Update Emplye Type !!
									</p>
								
					</div>
					
	"
	);
	return $response;
			}
	}
	public function emplyTypeDltById($id)
	{
		$id = $this->fm->validation($id);
		
		$id = mysqli_real_escape_string($this->db->conn,$id);
		$dltRes = $this->db->delete("EmployType"," id = '$id' ");
		if($dltRes != FALSE)
			{
				
				$response = array(
	"type" => "success",
	"message" => "
					<div class='alert alert-success alert-dismissible fade show p-0 mb-2' role='alert'>
									<p class='font-weight-bold text-secondary py-2 px-2 ml-1 mb-0'>
														Successfully Deleted Employee Type.
									</p>
								
					</div>
					
	"
	);
	return $response;
			}
			else
			{
				$response = array(
	"type" => "success",
	"message" => "
					<div class='alert alert-danger alert-dismissible fade show p-0 mb-2' role='alert'>
									<p class='font-weight-bold text-secondary py-2 px-2 ml-1 mb-0'>
														Fail to Deleted Emplye Type !!
									</p>
								
					</div>
					
	"
	);
	return $response;
			}
		
	}
	public function getLeftEmplyById($id)
	{
		$query = "SELECT Employee.cardNo,Employee.name,Department.deptname,Employee.dateOfBirth,Employee.fathername,Employee.mothername,Employee.maritalStatus,Employee.bloodGroup,Employee.NID
			FROM Employee
				INNER JOIN Department
				ON Employee.departmentId = Department.id AND Employee.id = '$id'
		";
		$rsReslt = $this->db->select($query);
		if($rsReslt != FALSE)
		{
			return $rsReslt;
		}
		else{
			return FALSE;
		}
	}
	public function getRightEmplyById($id)
	{
		$query = "SELECT Employee.presentAddress,Employee.permanentAddress,Employee.contuct,Education.eduName,Employee.email,Employee.gender,Employee.religion,Designation.desigName,Employee.signature,EmployType.emplyType
			FROM Employee
				INNER JOIN Education
					ON Employee.educationId = Education.id AND Employee.id = '$id'
				INNER JOIN Designation
					ON Employee.designationId = Designation.id AND Employee.id = '$id'
				INNER JOIN EmployType
					ON Employee.employTypeId = EmployType.id AND Employee.id = '$id'
		";
		$rsReslt = $this->db->select($query);
		if($rsReslt != FALSE)
		{
			return $rsReslt;
		}
		else{
			return FALSE;
		}
	}
	public function getEmployeeById($id)
	{
		$query = "SELECT * FROM Employee WHERE id ='$id' ";
			$result = $this->db->select($query);
			if($result != FALSE)
			{
				return $result;
			}
			else{
				return FALSE;
			}
	}
	public function udtNotiEmployeeTable($data)
	{
	
		// echo $password;
		// exit();
		
		$employeeId = $this->fm->validation($data["id"]);
		$maritalStatus = $this->fm->validation($data["maritalStatus"]);
		$NID = $this->fm->validation($data["NID"]);
		$educationId = $this->fm->validation($data["educationId"]);
		$presentAddress = $this->fm->validation($data["presentAddress"]);
		$permanentAddress = $this->fm->validation($data["permanentAddress"]);
		$contuct = $this->fm->validation($data["contuct"]);
		$email = $this->fm->validation($data["email"]);
		// echo $contuct;
		// exit();
		
		$employeeId = mysqli_real_escape_string($this->db->conn,$employeeId);
		$maritalStatus = mysqli_real_escape_string($this->db->conn,$maritalStatus);
		$NID = mysqli_real_escape_string($this->db->conn,$NID);
		$educationId = mysqli_real_escape_string($this->db->conn,$educationId);
		$presentAddress = mysqli_real_escape_string($this->db->conn,$presentAddress);
		$permanentAddress = mysqli_real_escape_string($this->db->conn,$permanentAddress);
		$contuct = mysqli_real_escape_string($this->db->conn,$contuct);
		$email = mysqli_real_escape_string($this->db->conn,$email);
		$emplyId = base64_encode($employeeId);
		// echo $contuct;
		// exit();
		
		
		Session::sess_set("maritalStatus",$maritalStatus);
		Session::sess_set("NID",$NID);
		Session::sess_set("educationId",$educationId);
		Session::sess_set("gender",$gender);
		Session::sess_set("presentAddress",$presentAddress);
		Session::sess_set("permanentAddress",$permanentAddress);
		Session::sess_set("contuct",$contuct);
		Session::sess_set("email",$email);
		
		// echo $cardNo."<br>";
		// echo $table_name;
		// exit();
		
		$permited = array("jpg","jpeg","png","gif");
		//for profile image upload............
		$pimg_file_name = $_FILES['pimage']['name'];
		$pimg_file_size = $_FILES['pimage']['size'];
		// Get Image Dimension
		$pimg_info = @getimagesize($_FILES['pimage']['tmp_name']);
		$pwidth = $pimg_info[0];
	$pheight = $pimg_info[1];
		$pdiv = explode(".",$pimg_file_name);
		$pextension = strtolower(end($pdiv));
		$puniq = substr(md5(time()),0,10).".".$pextension;
		$pupload = "images/profile/$puniq";

		// if noti_employeProfileStatus data already exist then can't insart any data again
		$alreadyquery = "SELECT * FROM noti_employeProfileStatus WHERE employeeId ='$employeeId' AND status ='0'  ";
		// echo $query;
		// exit();
		$alresult = $this->db->select($alreadyquery);
		if($alresult != FALSE)
		{
			$response = array(
		"type" => "success",
		"pendingMsg" => "
						<div class='alert alert-danger alert-dismissible fade show p-0 mb-2' role='alert'>
										<p class='font-weight-bold text-secondary py-2 px-2 ml-1 mb-0'>
															Data Already Exist !!
														
										</p>
									
						</div>
						
		");
			return $response;
		}
		
		if(empty($employeeId) || empty($maritalStatus) ||empty($NID) ||empty($educationId) ||empty($presentAddress) ||empty($permanentAddress) ||empty($contuct) ||empty($email)  )
		{
			$response = array(
"type" => "error",
"message" => "
				<div class='alert alert-danger alert-dismissible fade show p-0 mb-2' role='alert'>
								<p class='font-weight-bold text-secondary py-2 px-2 ml-1 mb-0'>Field Can't Empty!!</p>
							
				</div>
"
		);
			return $response;
		}
		else if(!empty($pimg_file_name))
		{
			
			// IMAGE VALIDATION CHECK.......................
			if($pimg_file_size > 2000000)
			{
				$response = array(
				"type" => "error",
				"message" => "
								<div class='alert alert-danger alert-dismissible fade show p-0 mb-2' role='alert'>
												<p class='font-weight-bold text-secondary py-2 px-2 ml-1 mb-0'>Photo Size exceeds <span class='text-primary'>2MB</span></p>
											
								</div>
				"
				);
				return $response;
			}
		else if(in_array($pextension,$permited) === FALSE)
			{
				$response = array(
				"type" => "error",
				"message" => "
								<div class='alert alert-danger alert-dismissible fade show p-0 mb-2' role='alert'>
												<p class='font-weight-bold text-secondary py-2 px-2 ml-1 mb-0'>
																	You can upload only <span class='text-primary'>".implode(',',$permited)."</span>
												</p>
											
								</div>
				"
				);
				return $response;
			}
			else if ($pwidth > "300" || $pheight > "300")
			{
				$response = array(
				"type" => "error",
				"message" => "
								<div class='alert alert-danger alert-dismissible fade show p-0 mb-2' role='alert'>
												<p class='font-weight-bold text-secondary py-2 px-2 ml-1 mb-0'>
																	Photo dimension should be within <span class='text-primary'>(300X300)</span>
												</p>
											
								</div>
								
				"
				);
				return $response;
			}
			
			else{
			
				$emyQuery = "SELECT maritalStatus,NID,educationId,presentAddress,permanentAddress,contuct,email FROM Employee WHERE id = '$employeeId' ";
				
				$emyReslt = $this->db->select($emyQuery);
				// 1st IF start
				if($emyReslt != FALSE)
				{
					// Assocative Array
					$empValue = $emyReslt->fetch_assoc();
   
					// User get change value or not, check it...................
					$noUpdate = count(array_intersect_assoc($empValue, $data));
					
					// 2nd if start
					// USER UPDATE HIS PROFILE(true).
					if($noUpdate < 7)
					{
						// EMAIL CHECK VALIDATION.....................
						$emlQuery = "SELECT id FROM Employee WHERE email= '$email' LIMIT 1 ";
						$emlReslt = $this->db->select($emlQuery);
						//3rd if start........
						if($emlReslt != FALSE)
						{
							$emlValue = $emlReslt->fetch_assoc();
					//1. CONDITION FOR SAME EMAIL..........................
							// 4th if start.......
							if(Session::sess_get('emplyId') == $emlValue['id'])
							{
								$ass_data = array("employeeId"=>$employeeId,"maritalStatus"=>$maritalStatus,"NID"=>$NID,"educationId"=>$educationId,"presentAddress"=>$presentAddress,"permanentAddress"=>$permanentAddress,"contuct"=>$contuct,"email"=>$email,"notiEmpImg"=>$pupload,"status"=>'0');
								// echo "<pre>";
								// print_r($ass_data);
								// echo "</pre>";
								// exit();

									$chgresult = $this->db->insert("noti_employeProfileStatus",$ass_data);
						
									move_uploaded_file($_FILES['pimage']['tmp_name'],$pupload);
									Session::sess_set("maritalStatus",NULL);
									Session::sess_set("NID",NULL);
									Session::sess_set("educationId",NULL);
									Session::sess_set("gender",NULL);
									Session::sess_set("presentAddress",NULL);
									Session::sess_set("permanentAddress",NULL);
									Session::sess_set("contuct",NULL);
									Session::sess_set("email",NULL);
								if($chgresult != FALSE)
									{
									$response = array(
									"type" => "success",
									"message" => "
													<div class='alert alert-success alert-dismissible fade show p-0 mb-2' role='alert'>
														<p class='font-weight-bold text-secondary py-2 px-2 ml-1 mb-0'>
																			Successfully Added Same Email upload Image. Your request is pending for Update.
																			<a href='emplyList.php'><b class='text-primary'>GO BACK </b> </a>
																			||
																			<a href='empViewStatus.php?emplyId=$emplyId '><b class='text-primary'>View Status </b> </a>
														</p>
																
													</div>
													
									"
									);
									return $response;
											
										header("Location: emplyList.php");
										exit();
									}
								
							} // 4th if end.......
							// 3. EMAIL ALREADY EXISTANCE FOR ANOTHER employee...................
							else
							{
								$response = array(
								"type" => "error",
								"message" => "
								<div class='alert alert-danger alert-dismissible fade show p-0 mb-2' role='alert'>
												<p class='font-weight-bold text-secondary py-2 px-2 ml-1 mb-0'>
																	THIS EMAIL ALREAY EXIST FOR ANOTHER USER. PLEASE CHANGE YOUR EMAIL.
												</p>
											
								</div>
												
								"
								);
								return $response;
							}
						}   //3rd if END........
						//2. INPUT EMAIL NOT FOUND(true)..............................
						else
						{
								$ass_data = array("employeeId"=>$employeeId,"maritalStatus"=>$maritalStatus,"NID"=>$NID,"educationId"=>$educationId,"presentAddress"=>$presentAddress,"permanentAddress"=>$permanentAddress,"contuct"=>$contuct,"email"=>$email,"notiEmpImg"=>$pupload,"status"=>'0');
									$chgresult = $this->db->insert("noti_employeProfileStatus",$ass_data);
						
									move_uploaded_file($_FILES['pimage']['tmp_name'],$pupload);
									Session::sess_set("maritalStatus",NULL);
									Session::sess_set("NID",NULL);
									Session::sess_set("educationId",NULL);
									Session::sess_set("gender",NULL);
									Session::sess_set("presentAddress",NULL);
									Session::sess_set("permanentAddress",NULL);
									Session::sess_set("contuct",NULL);
									Session::sess_set("email",NULL);
								if($chgresult != FALSE)
									{
										
										$response = array(
								"type" => "success",
								"message" => "
												<div class='alert alert-success alert-dismissible fade show p-0 mb-2' role='alert'>
													<p class='font-weight-bold text-secondary py-2 px-2 ml-1 mb-0'>
																		Successfully Added with Changed Email. Your request is pending for Update.
																		<a href='emplyList.php'><b class='text-primary'>GO BACK </b> </a>
																		||
																		<a href='empViewStatus.php?emplyId=$emplyId '><b class='text-primary'>View Status </b> </a>
													</p>
															
												</div>
												
								"
								);
								return $response;
										header("Location: emplyList.php");
									exit();
									}
								
						} //3rd if END........
					
						
						
					}
					// any field not changed.............................
					else
					{
						$response = array(
						"type" => "error",
						"message" => "
										<div class='alert alert-danger alert-dismissible fade show p-0 mb-2' role='alert'>
														<p class='font-weight-bold text-secondary py-2 px-2 ml-1 mb-0'>
																			Any Field Not Changed. Please change Any field and Click Update button.
														</p>
													
										</div>
										
						"
						);
						return $response;
					} // 2nd if END...........

				}	// 1st IF End	
			} //else end.............................
		} //else if end..........................
		///  empty upload image.....................................
		else if(empty($pimg_file_name))
		{


			
 // field compare AND email validation(same email,exist emil for another employee,new email) without image upload START

			$emyQuery = "SELECT maritalStatus,NID,educationId,presentAddress,permanentAddress,contuct,email FROM Employee WHERE id = '$employeeId' ";
				
				$emyReslt = $this->db->select($emyQuery);
				// 1st IF start
				if($emyReslt != FALSE)
				{
					// Assocative Array
					$empValue = $emyReslt->fetch_assoc();
   
					// User get change value or not, check it...................
					$noUpdate = count(array_intersect_assoc($empValue, $data));
					
					// 2nd if start
					// USER UPDATE HIS PROFILE(true).
					if($noUpdate < 7)
					{
						// EMAIL CHECK VALIDATION.....................
						$emlQuery = "SELECT id FROM Employee WHERE email= '$email' LIMIT 1 ";
						$emlReslt = $this->db->select($emlQuery);
						//3rd if start........

						// GIVE NEW EMAIL OR NOT(CHECK)
						if($emlReslt != FALSE)
						{
							$emlValue = $emlReslt->fetch_assoc();
					//1. CONDITION FOR SAME EMAIL..........................
							// 4th if start.......
							if(Session::sess_get('emplyId') == $emlValue['id'])
							{
								$ass_data = array("employeeId"=>$employeeId,"maritalStatus"=>$maritalStatus,"NID"=>$NID,"educationId"=>$educationId,"presentAddress"=>$presentAddress,"permanentAddress"=>$permanentAddress,"contuct"=>$contuct,"email"=>$email,"status"=>'0');

									$chgresult = $this->db->insert("noti_employeProfileStatus",$ass_data);
						
									move_uploaded_file($_FILES['pimage']['tmp_name'],$pupload);
									Session::sess_set("maritalStatus",NULL);
									Session::sess_set("NID",NULL);
									Session::sess_set("educationId",NULL);
									Session::sess_set("gender",NULL);
									Session::sess_set("presentAddress",NULL);
									Session::sess_set("permanentAddress",NULL);
									Session::sess_set("contuct",NULL);
									Session::sess_set("email",NULL);
								if($chgresult != FALSE)
									{
										
										$response = array(
								"type" => "success",
								"message" => "
												<div class='alert alert-success alert-dismissible fade show p-0 mb-2' role='alert'>
																<p class='font-weight-bold text-secondary py-2 px-2 ml-1 mb-0'>
																	Successfully Added without add Image in same mail. Your request is pending for Update  With same email.
																	<a href='emplyList.php'><b class='text-primary'>GO BACK </b> </a>
																	||
																	<a href='empViewStatus.php?emplyId=$emplyId '><b class='text-primary'>View Status </b> </a>
																</p>
															
												</div>
												
								"
								);
								return $response;
										header("Location: emplyList.php");
									exit();
									}
								
							} // 4th if end.......
							// 3. EMAIL ALREADY EXISTANCE FOR ANOTHER employee...................
							else
							{
								$response = array(
								"type" => "error",
								"message" => "
								<div class='alert alert-danger alert-dismissible fade show p-0 mb-2' role='alert'>
												<p class='font-weight-bold text-secondary py-2 px-2 ml-1 mb-0'>
																	THIS EMAIL ALREAY EXIST FOR ANOTHER USER not uload image. PLEASE CHANGE YOUR EMAIL.
												</p>
											
								</div>
												
								"
								);
								return $response;
							}
						}   //3rd if END........
						//2. INPUT EMAIL NOT FOUND(true)..............................
						else
						{
								$ass_data = array("employeeId"=>$employeeId,"maritalStatus"=>$maritalStatus,"NID"=>$NID,"educationId"=>$educationId,"presentAddress"=>$presentAddress,"permanentAddress"=>$permanentAddress,"contuct"=>$contuct,"email"=>$email,"status"=>'0');

									$chgresult = $this->db->insert("noti_employeProfileStatus",$ass_data);
						
									move_uploaded_file($_FILES['pimage']['tmp_name'],$pupload);

									Session::sess_set("maritalStatus",NULL);
									Session::sess_set("NID",NULL);
									Session::sess_set("educationId",NULL);
									Session::sess_set("gender",NULL);
									Session::sess_set("presentAddress",NULL);
									Session::sess_set("permanentAddress",NULL);
									Session::sess_set("contuct",NULL);
									Session::sess_set("email",NULL);

								if($chgresult != FALSE)
									{
										
										$response = array(
								"type" => "success",
								"message" => "
												<div class='alert alert-success alert-dismissible fade show p-0 mb-2' role='alert'>
													<p class='font-weight-bold text-secondary py-2 px-2 ml-1 mb-0'>
																		Successfully Added with Changed Email WITHOUT image. Your request is pending for Update.
																		<a href='emplyList.php'><b class='text-primary'>GO BACK </b> </a>
																		||
																		<a href='empViewStatus.php?emplyId=$emplyId '><b class='text-primary'>View Status </b> </a>
													</p>
															
												</div>
												
								"
								);
								return $response;
										header("Location: emplyList.php");
									exit();
									}
								
						} //3rd if END........
					
						
						
					}
					// any field not changed.............................
					else
					{
						$response = array(
						"type" => "error",
						"message" => "
										<div class='alert alert-danger alert-dismissible fade show p-0 mb-2' role='alert'>
														<p class='font-weight-bold text-secondary py-2 px-2 ml-1 mb-0'>
																			Any Field Not Changed witjhout image. Please change Any field and Click Update button.
														</p>
													
										</div>
										
						"
						);
						return $response;
					} // 2nd if END...........

				}



// field compare AND email validation(same email,exist emil for another employee,new email) without image upload END
				
		
			



				
		} // main else if END.......................
	}

	public function requestPendingCheck($id)
	{	
		$emplyId = base64_encode($id);
		$query = "SELECT * FROM noti_employeProfileStatus WHERE employeeId ='$id' AND status ='0' ";
		$result = $this->db->select($query);
		if($result != FALSE)
		{
			$response = array(
		"type" => "error",
		"pendingMsg" => "
						<div class='alert alert-danger alert-dismissible fade show p-0 mb-2' role='alert'>
										<p class='font-weight-bold text-secondary py-2 px-2 ml-1 mb-0'>
															You already hava a pending Request. Please wait until it Clear.
														<a href='emplyList.php'><b class='text-primary'>GO BACK </b> </a>
														||
															<a href='empViewStatus.php?emplyId=$emplyId '><b class='text-primary'>View Status </b> </a>
										</p>
									
						</div>
						
		");
			return $response;
		}
		
	}
	// date:19/02/19....................
	public function getnoti_employeProfileStatu($id)
	{
		// $query = "SELECT * FROM noti_employeProfileStatus WHERE employeeId ='$id' AND status ='$status' ORDER BY id DESC LIMIT 1 ";
		$id = $this->fm->validation($id);
		
		$id = mysqli_real_escape_string($this->db->conn,$id);
		$query = "SELECT noti_employeProfileStatus.*,Employee.name
				FROM noti_employeProfileStatus
				INNER JOIN Employee
					ON noti_employeProfileStatus.employeeId = Employee.id AND noti_employeProfileStatus.employeeId ='$id'
		";
		$result = $this->db->select($query);
		if($result != FALSE)
		{
			return $result;
		}
		else{
			return FALSE;
		}
	}


	public function notiShowForEmployee($id)
		{
		
		$id = $this->fm->validation($id);
		
		$id = mysqli_real_escape_string($this->db->conn,$id);

		$query = "SELECT noti_employeProfileStatus.*,Employee.name
				FROM noti_employeProfileStatus
				INNER JOIN Employee
					ON noti_employeProfileStatus.employeeId = Employee.id AND noti_employeProfileStatus.employeeId ='$id' AND noti_employeProfileStatus.status = '0'
		";

		$result = $this->db->select($query);
		// echo $value = $result->num_rows();
		// exit();
		if($result != FALSE)
		{
			return $result;
		}
		else{
			return FALSE;
		}
		
	}

	public function getEmplyOldProfileInfo($employeeId)
	{
		$employeeId = $this->fm->validation($employeeId);
		
		$employeeId = mysqli_real_escape_string($this->db->conn,$employeeId);

		// $query = "SELECT Employee.name,Employee.maritalStatus,Employee.NID,Education.eduName,Employee.presentAddress,Employee.permanentAddress,Employee.contuct,Employee.email,Employee.image
		// 	FROM Employee
		// 		INNER JOIN Education
		// 		ON Employee.educationId = Education.id AND Employee.id = '$employeeId'
		// ";

		$query = "SELECT em.name,em.maritalStatus,em.NID,ed.eduName,em.presentAddress,em.permanentAddress,em.contuct,em.email,em.image 
			FROM Employee AS em, Education AS ed 
				WHERE em.educationId = ed.id AND em.id = '$employeeId'
		";
		$result = $this->db->select($query);
		// echo $value = $result->num_rows();
		// exit();
		if($result != FALSE)
		{
			return $result;
		}
		else{
			return FALSE;
		}
	}

	public function getEmplyUdtProfileInfo($employeeId,$status)
	{
		$employeeId = $this->fm->validation($employeeId);
		$status = $this->fm->validation($status);
		
		$employeeId = mysqli_real_escape_string($this->db->conn,$employeeId);
		$status = mysqli_real_escape_string($this->db->conn,$status);

		$query = "SELECT Employee.name,noti_employeProfileStatus.maritalStatus,noti_employeProfileStatus.NID,Education.eduName,noti_employeProfileStatus.presentAddress,noti_employeProfileStatus.permanentAddress,noti_employeProfileStatus.contuct,noti_employeProfileStatus.email,noti_employeProfileStatus.notiEmpImg
			FROM noti_employeProfileStatus
				INNER JOIN Employee
				ON  noti_employeProfileStatus.employeeId = '$employeeId' AND noti_employeProfileStatus.status = '$status' AND noti_employeProfileStatus.employeeId = Employee.id

				INNER JOIN Education
				ON  noti_employeProfileStatus.employeeId = '$employeeId' AND noti_employeProfileStatus.status = '$status' AND noti_employeProfileStatus.educationId = Education.id 
		";
		$result = $this->db->select($query);
		// echo $value = $result->num_rows();
		// exit();
		if($result != FALSE)
		{
			return $result;
		}
		else{
			return FALSE;
		}
	}

	public function noNotificationByEmplyId($id)
	{
		$query = "SELECT * FROM noti_employeProfileStatus WHERE employeeId ='$id' ";

		

		$result = $this->db->select($query);
		// echo $value = $result->num_rows();
		// exit();
		if($result != FALSE)
		{
			return $result;
		}
		else{
			return FALSE;
		}
	}
}
?>