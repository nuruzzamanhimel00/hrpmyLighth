<div class="adminContain">
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-3">
						<aside style="height: 100%;background: #ddd;">
							<ul class="list-group">
								<a href="#"> <li class="list-group-item list-group-item-edt "><i class="fas fa-users"></i> Side menu 1</li>
							</a>
							
							<li class="list-group-item list-group-item-edt">
								<i class="fas fa-users"></i> Employee
								<ul  class="list-group list-group-flush">
									<a href="addEmployee.php" ><li class="list-group-item list-group-item-edt ">
										<p class="mb-0">Add Employee</p>
									</li></a>
									<a href="emplyList.php"><li class="list-group-item list-group-item-edt ">
										<p class="mb-0">Employee List</p>
									</li></a>
									<a href="addEmpType.php"><li class="list-group-item list-group-item-edt ">
										<p class="mb-0">
										<i class="fas fa-plus-square"></i>Add Employee Type</p>
									</li></a>
									<!-- <a href="empTypeList.php"><li class="list-group-item list-group-item-edt ">
										<p class="mb-0">Employee Type List</p>
									</li></a> -->
									
								</ul>
							</li>

							<li class="list-group-item list-group-item-edt">
								<i class="fas fa-users"></i> Department
								<ul  class="list-group list-group-flush">
									<a href="addDepartment.php" ><li class="list-group-item list-group-item-edt ">
										<p class="mb-0">
										<i class="fas fa-plus-square"></i>Add Department</p>
									</li></a>
									<a href="departmentList.php"><li class="list-group-item list-group-item-edt ">
										<p class="mb-0">
										<i class="fas fa-list-alt"></i>Department List</p>
									</li></a>
									
								</ul>
							</li>
							<li class="list-group-item list-group-item-edt">
								<i class="fas fa-users"></i> Designation
								<ul  class="list-group list-group-flush">
									<a href="addDesignation.php" ><li class="list-group-item list-group-item-edt ">
										<p class="mb-0">
										<i class="fas fa-plus-square"></i>Add Designation</p>
									</li></a>
									<a href="designationList.php"><li class="list-group-item list-group-item-edt ">
										<p class="mb-0">
										<i class="fas fa-list-alt"></i>Designation List</p>
									</li></a>
									
								</ul>
							</li>
							
							<li class="list-group-item list-group-item-edt">
								<i class="fas fa-users"></i> Attandance
								<ul  class="list-group list-group-flush">
									<a href="managAttend.php" >
										<li class="list-group-item list-group-item-edt ">
											<p class="mb-0">
												<i class="fas fa-paperclip"></i>
												Mange Attandance
											</p>
										</li></a>
										<a href="attendReport.php"><li class="list-group-item list-group-item-edt ">
											<p class="mb-0"><i class="fas fa-paperclip"></i>Attandance Report</p>
										</li></a>
										
									</ul>
								</li>
								<li class="list-group-item list-group-item-edt">
									<i class="fas fa-users"></i> Notice Board
									<ul  class="list-group list-group-flush">
									<a href="addNotice.php" >
										<li class="list-group-item list-group-item-edt ">
											<p class="mb-0">
												<i class="fas fa-plus-square"></i>
												Add Notice
											</p>
										</li></a>
										<a href="noticeList.php"><li class="list-group-item list-group-item-edt ">
											<p class="mb-0">
												<i class="fas fa-address-card"></i>
												Notice List
											</p>
										</li></a>
										
									</ul>
								</li>
								<li class="list-group-item list-group-item-edt">
									<i class="fas fa-university"></i> Education
									<ul  class="list-group list-group-flush">
									<a href="addEducation.php" >
										<li class="list-group-item list-group-item-edt ">
											<p class="mb-0">
												<i class="fas fa-plus-square"></i>
												Add Education Field
											</p>
										</li></a>
										<a href="educationList.php"><li class="list-group-item list-group-item-edt ">
											<p class="mb-0">
												<i class="fas fa-address-card"></i>
												Education Field List
											</p>
										</li></a>
										
									</ul>
								</li>
								<li class="list-group-item list-group-item-edt">
									<i class="fas fa-university"></i> Leave
									<ul  class="list-group list-group-flush">
									<a href="addLeaveType.php" >
										<li class="list-group-item list-group-item-edt ">
											<p class="mb-0">
												<i class="fas fa-plus-square"></i>
												Add Leave Type
											</p>
										</li>
									</a>
										<a href="leaveList.php">
											<li class="list-group-item list-group-item-edt ">
											<p class="mb-0">
												<i class="fas fa-address-card"></i>
												Leave Type List
											</p>
											</li>
										</a>
										<a href="leaveApplication.php">
											<li class="list-group-item list-group-item-edt ">
											<p class="mb-0">
												<i class="fas fa-newspaper"></i>
												Leave Application
											</p>
											</li>
										</a>
										<a href="leaveView.php">
											<li class="list-group-item list-group-item-edt ">
											<p class="mb-0">
												<i class="fas fa-newspaper"></i>
												Leave View
											</p>
											</li>
										</a>
										<a href="leaveView.php">
											<li class="list-group-item list-group-item-edt ">
											<p class="mb-0">
												<i class="fas fa-newspaper"></i>
												Leave View
											</p>
											</li>
										</a>
										
									</ul>
								</li>
									<li class="list-group-item list-group-item-edt">
									<i class="fas fa-university"></i> Requisition
									<ul  class="list-group list-group-flush">
									<a href="addRequiType.php" >
										<li class="list-group-item list-group-item-edt ">
											<p class="mb-0">
												<i class="fas fa-plus-square"></i>
												Add Requisition Type
											</p>
										</li>
									</a>
										<a href="reqiositionList.php">
											<li class="list-group-item list-group-item-edt ">
											<p class="mb-0">
												<i class="fas fa-address-card"></i>
												 Requisition List
											</p>
											</li>
										</a>
										<a href="requiApplication.php">
											<li class="list-group-item list-group-item-edt ">
											<p class="mb-0">
												<i class="fas fa-newspaper"></i>
												Requisition For Appli
											</p>
											</li>
										</a>
										<a href="requisitionView.php">
											<li class="list-group-item list-group-item-edt ">
											<p class="mb-0">
												<i class="fas fa-newspaper"></i>
												 View Requisition
											</p>
											</li>
										</a>
										
									</ul>
								</li>
								
								<a href="#"> <li class="list-group-item list-group-item-edt "> <i class="fas fa-users"></i>Side menu 2</li>
							</a>
							<a href="#"> <li class="list-group-item list-group-item-edt "><i class="fas fa-users"></i>Side menu 3</li>
						</a>
						<a href="#"> <li class="list-group-item list-group-item-edt "><i class="fas fa-users"></i>Side menu 4</li>
					</a>
					<li class="list-group-item list-group-item-edt">
						<i class="fas fa-users"></i>Side Menu 2
						<ul  class="list-group list-group-flush">
							<a href="#"><li class="list-group-item list-group-item-edt ">List 1</li></a>
							<a href="#"><li class="list-group-item list-group-item-edt ">List 1</li></a>
							<a href="#"><li class="list-group-item list-group-item-edt  ">List 1</li></a>
						</ul>
					</li>
				</ul>
			</aside>
		</div>