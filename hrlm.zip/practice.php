<?php
 // $array1 = array("a" => "Orange", "b" => "Apple", "c" => "Banana", "Chery");
 //  $array2 = array("a" =>"Orange", "Banana","Mango");
 //  $c = count(array_intersect($array1, $array2));
 //  echo $c;
?>
<?php
// $array1=array("Orange" => 100, "Apple" => 200, "Banana" => 300, "Cherry" => 400);
// $array2=array("Orange" => 100, "Apple" => 200, "Banana" => 400);
// $result=count(array_intersect($array1, $array2));
// //print_r($result);
// echo $result;
?>
<?php
$array1 = array("a" => "Orange", "b" => "Apple", "c" => "Banana");
$array2 = array("a" =>"Orange","b" => "Applee", "c" => "Banana");
// $result = var_dump(array_intersect_assoc($array1, $array2));
$result = count(array_intersect_assoc($array1, $array2));
//print_r($result)
echo $result;
?>