<?php include("inc/header.php"); ?>
<?php include("inc/aside.php"); ?>
<?php 
	if(isset($_GET['vid']) AND !empty($_GET['vid']))
	{
		$id = base64_decode($_GET['vid']);
	}
	// else{
	// 	echo ""
	// }
?>
<style type="text/css">
	.profileImg{width: 100%;}
	.profileImg img {
	margin: 0px auto;
	display: block;
	width: 177px;
	background: #fff;
	border: 1px solid #ddd;
	padding: 5px;
	border-radius: 50%;
	margin-bottom: 13px;
}
</style>
<div class="col-md-9" style="margin-bottom: 20px;">
	<div class="bodySection">
		<div class="row mb-3 text-white " style="background: #B0B0FC !important;width: 101%;height: 44px;margin-left: -5px;">
			<div class="col-md-12" style="font-weight: bold;margin: 8px 5px;font-size: 18px; text-align: center;">
				Employee Profile
			</div>
		</div>
	<?php 
		if($_SERVER["REQUEST_METHOD"] == "POST" AND isset($_POST['submit']))
		{
			$addEmp = $em->addEmployee($_POST);
		}
	?>	
	<?php 
		if(!empty($addEmp))
		{
			echo $addEmp["message"];
		}
	?>
		<div class="row mb-3">
			<div class="col-md-12"> 
				<div class="profileImg"> 
		<?php 
			$getReslt = $em->getEmployeeById($id);
			if($getReslt != FALSE)
			{
				$getvalue = $getReslt->fetch_assoc();
			
		?>				
					<img src="<?php echo $getvalue['image'];  ?>">
		<?php } ?>			
				</div>
			</div>
			
			<div class="col-md-6 emplyCol8">
					<div class="emplyForm">
						<table class="table table-striped table-bordered table-hover table-sm" style="border: 1px solid #ddd;border-radius: 3px;">
				<?php 
					$rsReslt = $em->getLeftEmplyById($id);
					if($rsReslt != FALSE)
					{
						$rsValue = $rsReslt->fetch_assoc();
					
				?>			 
							  <tbody>
							    <tr>
							     <th width="20%">CardNo</th><td  width="5%" >:</td>
							     	<td  width="20%">
							     	<?php echo $rsValue['cardNo'];  ?>
							     		
							     	</td>
							      
							    </tr>
							    <tr>
							     <th >Name </th><td>:</td><td>
							     	<?php echo $rsValue['name'];  ?>
							     </td>
							      
							    </tr>
							    <tr>
							     <th >Department</th><td>:</td><td>
							     	<?php echo $rsValue['deptname'];  ?>
							     </td>
							      
							    </tr>
							    <tr>
							     <th >D&B</th><td>:</td><td>
							     	<?php echo $rsValue['dateOfBirth'];  ?>
							     </td>
							      
							    </tr>
							    <tr>
							     <th >Father NM</th><td>:</td><td>
							     	<?php echo $rsValue['fathername'];  ?>
							     </td>
							      
							    </tr>
							    <tr>
							     <th >Mother NM</th><td>:</td><td>
							     	<?php echo $rsValue['mothername'];  ?>
							     </td>
							      
							    </tr>
							    <tr>
							     <th >Status</th><td>:</td><td>
							     
							     	<?php 
							     		if($rsValue['maritalStatus'] == '1')
							     			{echo "Married";}
							     		else if($rsValue['maritalStatus'] == '2')
							     			{echo "Unmarried";}
							     		else if($rsValue['maritalStatus'] == '3')
							     			{echo "Divorced";}
							     		else if($rsValue['maritalStatus'] == '4')
							     			{echo "Widoweb";}
							     		else if($rsValue['maritalStatus'] == '5')
							     			{echo "Separeted";}
							     		

							     	  ?>
							     </td>
							      
							    </tr>
							    <tr>
							     <th >Blood GR</th><td>:</td><td>
							     	<?php echo $rsValue['bloodGroup'];  ?>
							     </td>
							      
							    </tr>
							    <tr>
							     <th >NID</th><td>:</td><td>
							     	<?php echo $rsValue['NID'];  ?>
							     </td>
							      
							    </tr>
							    <tr>
							     

							    
							  </tbody>
						<?php } ?>	  
					</table>
							
					</div>
						<!-- 	.col-md-6 div end..................... -->
					</div>
					<div class="col-md-6">
							<div class="emplyForm">

								<table class="table table-striped table-bordered table-hover table-sm " style="border: 1px solid #ddd;border-radius: 3px;">
				<?php 
					$reReslt = $em->getRightEmplyById($id);
					if($reReslt != FALSE)
					{
						$reValue = $reReslt->fetch_assoc();
					
				?>					
							 
							   <tbody>
							    <tr>
							     <th width="20%">Present Ad</th><td  width="5%" >:</td>
							     	<td  width="20%">
							     	<?php echo $reValue['presentAddress'];  ?>
							     		
							     	</td>
							      
							    </tr>
							    <tr>
							     <th >Permanent Ad </th><td>:</td><td>
							     	<?php echo $reValue['permanentAddress'];  ?>
							     </td>
							      
							    </tr>
							    <tr>
							     <th >Contuct No</th><td>:</td><td>
							     	<?php echo $reValue['contuct'];  ?>
							     </td>
							      
							    </tr>
							    <tr>
							     <th >Qualification</th><td>:</td><td>
							     	<?php echo $reValue['eduName'];  ?>
							     </td>
							      
							    </tr>
							    <tr>
							     <th >Email</th><td>:</td><td>
							     	<?php echo $reValue['email'];  ?>
							     </td>
							      
							    </tr>
							    <tr>
							     <th >Gender</th><td>:</td><td>
							     	<?php 
							     		if($reValue['gender'] == '1')
							     			{echo "Male";}
							     		else if($reValue['gender'] == '2')
							     			{echo "Female";}
							     		else{
							     			echo "Other";
							     		}

							     	  ?>
							     </td>
							      
							    </tr>
							    <tr>
							     <th >Religion</th><td>:</td><td>
							
							     	<?php 
							     		if($reValue['religion'] == '1')
							     			{echo "Islam";}
							     		else if($reValue['religion'] == '2')
							     			{echo "Hinduism";}
							     		else if($reValue['religion'] == '3')
							     			{echo "Buddhists";}
							     		else if($reValue['religion'] == '4')
							     			{echo "Christians";}
							     		else if($reValue['religion'] == '5')
							     			{echo "Animists";}
							     		

							     	  ?>
							     </td>
							      
							    </tr>
							    <tr>
							     <th >Designation</th><td>:</td><td>
							     	<?php echo $reValue['desigName'];  ?>
							     </td>
							      
							    </tr>
							    
							    <tr>
							     <th >Employee CT</th><td>:</td><td>
							     	<?php echo $reValue['emplyType'];  ?>
							     </td>
							      
							    </tr>

							    <tr>
							     <th >Signature</th><td>:</td><td>
							     	<img src="<?php echo $reValue['signature']; ?>" width="50px">
							     </td>
							      
							    </tr>
							 
							     

							    
							  </tbody>
						<?php } ?>	  
					</table>
							
							</div>
					</div>
		</div>
				</div> <!-- col-md-10 end.............. -->
				<div class="backBtn">
					<a href="emplyList.php">
						<button type="submit" class="btn btn-primary" name="submit">BACK</button>
					</a>
					
				</div>
			</form>
		</div>
	</div>
</div>

<?php
include("inc/footer.php");
?>