<?php include("inc/header.php"); ?>
<?php include("inc/aside.php"); ?>
		<div class="col-md-9" style="margin-bottom: 20px;">
			<div class="bodySection">
				
				<div class="row">
					
					<div class="col-md-12 emplyCol8">
						<div class="setAtten" >
							<div class="addTitle">
								<p>Set Attandance</p>
							</div>
							
							<div class="addFrom">
								
								<form>
									<div class="form-group row">
										<label for="staticEmail" class="col-sm-2 col-form-label">Select Day</label>
										<div class="col-sm-5">
											<div class="input-group-addon"  >
												
											</div>
											<input type="date" class="datepicker form-control pull-right fp" id="datepicker">
										</div>
										
									</div>
									<div class="form-group row">
										<label for="inputPassword" class="col-sm-2 col-form-label">Department</label>
										<div class="col-sm-5">
											<select class="custom-select mr-sm-2" id="inlineFormCustomSelect">
												<option selected>Choose...</option>
												<option value="1">Dept 1</option>
												<option value="2">Dept 2</option>
												<option value="3">Dept 3</option>
												<option value="3">Dept 4</option>
												<option value="3">Dept 5</option>
											</select>
										</div>
									</div>
									<div class="gobtn">
										<button type="submit" class="btn btn-primary">Go</button>
									</div>
									
								</form>
							</div>
							
							
						</div>
						<!-- 	.col-md-6 div end..................... -->
					</div>

					<div class="col-md-12 emplyCol8">
						<div class="setAtten" style="background: none;border: none;" >
							<div class="emplyList">
								<p>Emplyee List</p>
							</div>
							
							<div class="" style="padding: 19px 10px;">

							<form style="margin:0px -41px;">	
									
								<table id="example" class="table table-striped table-bordered " style="width: 70%;border: 1px solid #ddd;">
									        <thead>
									            <tr>
									                <th scope="col">No</th>
									                 <th scope="col">Name</th>
									                <th scope="col" >Department</th>
									                <th scope="col">In Time</th>
									                <th scope="col" >Out Time</th>
									                <th scope="col" >Present</th>
									                <th scope="col">Absent</th>
									                
									            </tr>
									        </thead>
									        <tbody>
									            <tr>
									                <td scope="row">01</td>
									                <td>Md. Nuruzzaman</td>
									                <td>Web Dev</td>
									            
									                <td>
									                	<input type="time" name="">
									                </td>
									                <td>
									                	<input type="time" name="">
									                </td>
									                <td>
									                	<input type="checkbox" name="gender" value="Present">

									                </td>
									              	<td>
									              		  <input type="checkbox" name="gender" value="Absent">
									              	</td>
									            </tr>
												<tr>
									                <td scope="row">01</td>
									                <td>Md. Nuruzzaman</td>
									                <td>Web Dev</td>
									            
									                <td>
									                	<input type="time" name="">
									                </td>
									                <td>
									                	<input type="time" name="">
									                </td>
									                <td>
									                	<input type="checkbox" name="gender" value="Present">

									                </td>
									              	<td>
									              		  <input type="checkbox" name="gender" value="Absent">
									              	</td>
									            </tr>
									            <tr>
									                <td scope="row">01</td>
									                <td>Md. Nuruzzaman</td>
									                <td>Web Dev</td>
									            
									                <td>
									                	<input type="time" name="">
									                </td>
									                <td>
									                	<input type="time" name="">
									                </td>
									                <td>
									                	<input type="checkbox" name="gender" value="Present">

									                </td>
									              	<td>
									              		  <input type="checkbox" name="gender" value="Absent">
									              	</td>
									            </tr>
									            <tr>
									                <td scope="row">01</td>
									                <td>Md. Nuruzzaman</td>
									                <td>Web Dev</td>
									            
									                <td>
									                	<input type="time" name="">
									                </td>
									                <td>
									                	<input type="time" name="">
									                </td>
									                <td>
									                	<input type="checkbox" name="gender" value="Present">

									                </td>
									              	<td>
									              		  <input type="checkbox" name="gender" value="Absent">
									              	</td>
									            </tr>
									            <tr>
									                <td scope="row">01</td>
									                <td>Md. Nuruzzaman</td>
									                <td>Web Dev</td>
									            
									                <td>
									                	<input type="time" name="">
									                </td>
									                <td>
									                	<input type="time" name="">
									                </td>
									                <td>
									                	<input type="checkbox" name="gender" value="Present">

									                </td>
									              	<td>
									              		  <input type="checkbox" name="gender" value="Absent">
									              	</td>
									            </tr>
									            <tr>
									                <td scope="row">01</td>
									                <td>Md. Nuruzzaman</td>
									                <td>Web Dev</td>
									            
									                <td>
									                	<input type="time" name="">
									                </td>
									                <td>
									                	<input type="time" name="">
									                </td>
									                <td>
									                	<input type="checkbox" name="gender" value="Present">

									                </td>
									              	<td>
									              		  <input type="checkbox" name="gender" value="Absent">
									              	</td>
									            </tr>



									        </tbody>    
									              
									           
									    </table>

									  <div class="attenBtn">
									  	<button type="button" class="btn btn-primary" style="padding: 5px 10px;">Update</button>
									  </div>  
								
								</form>




							</div>
							
							
						</div>
						<!-- 	.col-md-6 div end..................... -->
					</div>
					
				</div>
				</div> <!-- col-md-10 end.............. -->
				
			</form>
		</div>
	</div>
</div>

<?php 
	include("inc/footer.php");
?>